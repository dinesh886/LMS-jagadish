import React, { useState, useEffect, useRef } from "react";
import { Link, useLocation } from "react-router-dom";
import {
  FaPlus,
  FaFileAlt,
  MdOutlinePublishedWithChanges,
  FaShare,
  FaPaperPlane,
  FaArchive,
  FaTrash,
  FaTag,
  FaChevronDown,
  FaChevronUp,
  FaCheck,
  FaTimes,
  FaArrowDown,
  FaArrowUp,


} from "react-icons/fa";
import NewTestModal from "../../../ReusableComponents/NewTestModal/NewTestModal";
import CloseIcon from '@mui/icons-material/Close';
import { RxCross2 } from "react-icons/rx";
import { IoIosArrowDropdown } from "react-icons/io";

import { MdDrafts } from "react-icons/md";
import "./TestSidebar.css";
import { IoMdPricetag } from "react-icons/io";
import { Divider } from "@mui/material";
import 'bootstrap/dist/css/bootstrap.min.css';
import AddTagsComponent from "../../../ReusableComponents/AddTagsComponent/AddTagsComponent";
import AddTagModal from "../../../ReusableComponents/AddTagModal/AddTagModal";
import TagActionsDropdown from "../../../ReusableComponents/TagActionsDropdown/TagActionsDropdown";



const TestSidebar = () => {

  const [isNewTagModalOpen, setIsNewTagModalOpen] = useState(false);
  const [isNewTestModalOpen, setIsNewTestModalOpen] = useState(false);
  const [showMoreOptions, setShowMoreOptions] = useState(null);
  const [isTagModalOpen, setIsTagModalOpen] = useState(false);
  
  const handleTagClick = (index) => {
    setShowMoreOptions(showMoreOptions === index ? null : index);
  };
  const location = useLocation(); // Get the current URL location
  // Set initial active section
  const [activeSection, setActiveSection] = useState("Alltest");
  const [activeTag, setActiveTag] = useState(""); // State to track active tag

  const handleAddtag = ({ name, color }) => {
    console.log("New Folder Created:", { name, color });
    // Add your logic to save the folder
  };
  // Function to set active section
  const handleSetActive = (section) => {
    setActiveSection(section);
  };
  // Function to set active tag
  const handleSetActiveTag = (tag) => {
    setActiveTag(tag);
  };

  // const isActive = (link) => {

  //   return window.location.pathname.includes(link) || window.location.pathname === "/";
  // };
  const [isModalOpen, setIsModalOpen] = useState(false); // Modal state
  const [testName, setTestName] = useState(""); // Test name input value
  const [duration, setDuration] = useState("");
  const [description, setDescription] = useState("");
  const [instruction, setInstruction] = useState("");
  const [isTestsVisible, setIsTestsVisible] = useState(true); // State to toggle Tests section visibility
  const [tags, setTags] = useState(["Tag 1", "Tag 2"]); // Tags state

  const [newTag, setNewTag] = useState("");
  const [tagColor, setTagColor] = useState("#ff0000"); // Default color for the tag
 
  const [showTagOptions, setShowTagOptions] = useState(false);

  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [currentPage, setCurrentPage] = useState(1);
  const [isCustomColor, setIsCustomColor] = useState(false);
  const [customColor, setCustomColor] = useState("#000000");
  const [tooltipVisible, setTooltipVisible] = useState(false);
  const [durationError, setDurationError] = useState(""); // State for error message
  console.log("tag modal", isTagModalOpen);
  const defaultColors = [
    "#FF5733", "#33FF57", "#3357FF", "#FF33A6", "#33FFEC",
    "#F7FF33", "#FF9633", "#9B33FF", "#33A6FF", "#FF5733"
  ];
  const [modalHeading, setModalHeading] = useState(""); // State for modal heading
    const [selectedSection, setSelectedSection] = useState(""); // State for selected section
  const dropdownRef = useRef(null);



  const handleDurationChange = (e) => {
    let value = e.target.value;
  
    if (value === "") {
      setDurationError("");
      setDuration("");
      setIsAddButtonEnabled(false);
      return;
    }
  
    // Show error for decimal values but retain the input
    if (value.includes(".")) {
      setDurationError("Only whole numbers are allowed.");
      setDuration(value);
      setIsAddButtonEnabled(false);
      return;
    }
  
    // Ensure the value remains a number if valid
    value = parseInt(value, 10);
  
    if (isNaN(value)) {
      setDurationError(""); 
      setDuration(value); 
      setIsAddButtonEnabled(false);
    } 
    // If the value is less than 1
    else if (value < 1) {
      setDurationError("Duration cannot be less than 1.");
      setDuration(value);
      setIsAddButtonEnabled(false);
    } 
    // If the value is greater than 600
    else if (value > 600) {
      setDurationError("Duration cannot be greater than 600.");
      setDuration(value); 
      setIsAddButtonEnabled(false);
    } 
    // If the value is valid (between 1 and 600)
    else {
      setDurationError("");
      setDuration(value);
      setIsAddButtonEnabled(true);
    }
  };
  
 
  // Define a dynamic color array for each tag
  // Define a dynamic color array for each icon
  const iconColors = ['#f44336', '#2196f3', '#ff9800', '#9c27b0']; // You can add more colors here

  const [isAddButtonEnabled, setIsAddButtonEnabled] = useState(false); // New state for enabling/disabling button

  const isFormValid = testName && duration && description && instruction; // Check if all fields are filled
  // Function to open the modal
  const handleOpenModal = () => {
    setIsModalOpen(true);
  };
  // Function to close the modal and reset input
  const handleCloseModal = () => {
    setIsModalOpen(false);
    setTestName(""); // Reset input field
  };
  const handleCreateClick = () => {
    // Close the tag modal
    setIsTagModalOpen(false);

    // Log a message for debugging or confirmation
    console.log("New tag created successfully!");

    // You can add additional logic here if needed, such as:
    // - Saving the new tag data
    // - Updating a state variable for tags
    // - Triggering a success notification
  };

  // Check if all fields are filled and enable the button accordingly
  useEffect(() => {
    if (
      testName &&
      duration &&
      description &&
      instruction &&
      /^[0-9]+$/.test(duration) && // Ensures duration is a whole number
      duration >= 1 &&
      duration <= 600
    ) {
      setIsAddButtonEnabled(true); // Enable button when all fields are valid
    } else {
      setIsAddButtonEnabled(false); // Disable button if any field is invalid
    }
  }, [testName, duration, description, instruction]);
  


  const handleCreateTest = () => {
    if (testName.trim() !== "") {
      console.log("Test Created:", { testName, duration, description, instruction });
      // Add logic to save the test here
    }
    handleCloseModal();
  };

  // Toggle Tests visibility
  const toggleTestsVisibility = () => {
    setIsTestsVisible(!isTestsVisible);
  };

 


  // const handleTagClick = (index) => {
  //   setShowMoreOptions(showMoreOptions === index ? null : index); 
  // };

  return (
    <nav className="test-sidebar-container" aria-label="Main Navigation">
      <div className="test-sidebar-header">
        <div className="w-100 d-flex justify-content-center">
        <button
            onClick={() => setIsNewTestModalOpen(true)}
          className=" allbuttons"
          aria-label="Create New Test"
        >
          {/* <FaPlus className="icon" /> */}
          <span className="sidebar-letters ">New Test</span>
        </button>

        </div>
       
      </div>




      <div className="test-sidebar-section">


        <ul className="test-sidebar-menu">
          <li>
            <Link
              to="Alltest"
              className={`sidebar-contents ${activeSection === "Alltest" ? "active" : ""}`}
              aria-label="All Tests"
              onClick={() => handleSetActive("Alltest")}
            >
              <FaFileAlt className="icon" />
              <span className="sidebar-letters">All Tests</span>
            </Link>
          </li>
          <li>
            <Link
              to="shared-with-me"
              className={`sidebar-contents ${activeSection === "shared-with-me" ? "active" : ""}`}
              aria-label="Shared with me"
              onClick={() => handleSetActive("shared-with-me")}
            >
              <FaShare className="icon" />
              <span className="sidebar-letters">Shared with me</span>
            </Link>
          </li>
          <li>
            <Link
              to="dispatched"
              className={`sidebar-contents ${activeSection === "dispatched" ? "active" : ""}`}
              aria-label="Dispatched"
              onClick={() => handleSetActive("dispatched")}
            >
              <FaPaperPlane className="icon" />
              <span className="sidebar-letters">Published</span>
            </Link>
          </li>
          {/* <li>
            <Link
              to="undispatched"
              className={`sidebar-contents ${activeSection === "undispatched" ? "active" : ""}`}
              aria-label="Undispatched"
              onClick={() => handleSetActive("undispatched")}
            >
              <MdDrafts className="icon" />
              <span className="sidebar-letters">Pending</span>
            </Link>
          </li> */}
          <li>
            <Link
              to="archived"
              className={`sidebar-contents ${activeSection === "archived" ? "active" : ""}`}
              aria-label="Archived"
              onClick={() => handleSetActive("archived")}
            >
              <FaArchive className="icon" />
              <span className="sidebar-letters">Archived</span>
            </Link>
          </li>
          <li>
            <Link
              to="trashed"
              className={`sidebar-contents ${activeSection === "trashed" ? "active" : ""}`}
              aria-label="Trashed"
              onClick={() => handleSetActive("trashed")}
            >
              <FaTrash className="icon" />
              <span className="sidebar-letters">Trashed</span>
            </Link>
          </li>
        </ul>
      </div>

       {/* Tag Creation Modal */}
       <AddTagsComponent
        isOpen={isTagModalOpen}
        onClose={() => setIsTagModalOpen(false)}
      />
     
      <hr  />

      <div className="sidebar-section">
        <button
          className="newtag"
          aria-label="Create New Test"
          onClick={() => {
            setIsNewTagModalOpen(true);
            setModalHeading("New Tag"); // Set the modal heading
          }}
        >

          <FaPlus className="icon" />
          <span className="sidebar-letters">New Tag</span>
        </button>

        <ul className="test-sidebar-menu tags">
          {tags.map((tag, index) => (
            <li key={index} className="tag-item">
              <Link
                className="sidebar-contents"
                aria-label={`Tag: ${tag}`}
              >
                <IoMdPricetag
                  className="icon"
                  style={{
                    color: iconColors[index % iconColors.length],
                    fontSize: "25px",
                  }}
                />
                <div className="w-100 d-flex justify-content-between align-items-center">
                  <span className="sidebar-letters">{tag}</span>

                  <button className="tag-button">
                    <span className="tag-dropdown-toggle" onClick={() => handleTagClick(index)}></span>
                  </button>

                  {/* Place Dropdown Inside Map to Access `index` */}
                  <TagActionsDropdown
                    isOpen={showMoreOptions === index}
                    onEdit={() => {
                      setIsNewTagModalOpen(true);
                      setShowMoreOptions(null);
                      setModalHeading("Edit "); // Set the modal heading
                      setSelectedSection(tags[index]); // Set the selected section name
                    }}
                    onRemove={() => setShowMoreOptions(null)}
                    onClose={() => setShowMoreOptions(null)}
                  />
                </div>
              </Link>
            </li>
          ))}
        </ul>


        <p className="sidebar-contents " style={{ fontStyle: "italic" }}> Uncategorized<span className="number">(5)</span></p>
      </div>
      <NewTestModal
        isOpen={isNewTestModalOpen}
        onClose={() => setIsNewTestModalOpen(false)}
        onCreate={handleCreateTest}
      />

     

      <AddTagModal isOpen={isNewTagModalOpen}
        onClose={() => setIsNewTagModalOpen(false)}
        onAddFolder={handleAddtag}
        
        heading={modalHeading} // Pass the dynamic heading
        selectedSection={selectedSection} // Pass the selected section name
        
        
        
        />

      {/* Use the TagDropdown component */}
      {/* <TagActionsDropdown
       isOpen={showMoreOptions === index}
        onEdit={() => {
          setIsTagModalOpen(true);
          setShowMoreOptions(null); 
        }}
        onRemove={() => setShowMoreOptions(null)}
        onClose={() => setShowMoreOptions(null)} /> */}
    </nav>


  );
};

export default TestSidebar;
