import React, { useState, useRef, useEffect } from 'react';
import { Link, useLocation, useParams } from "react-router-dom";
import './TestQuestionAddSidebar.css';
import { FaChevronDown } from 'react-icons/fa';
import { Award, Hash, Clock } from "lucide-react";
import TestQuestionAdd from './TestQuestionAdd'; // Import TestQuestionAdd component
import { useTestContext } from "../TestContext";
import { MdTimer, MdPlaylistAddCheck, MdExposureNeg1 } from "react-icons/md";
import { AiOutlineFileDone } from "react-icons/ai";


const TestQuestionAddSidebar = () => {
  const [isQuestionBankDropdownOpen, setIsQuestionBankDropdownOpen] = useState(false);
  const [activeDropdown, setActiveDropdown] = useState(null);
  const [marks, setMarks] = useState('');
  const [negativeMarks, setNegativeMarks] = useState('');
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [activeSection, setActiveSection] = useState(null);
  const { setQuestionsToShow } = useTestContext();  // Questions for the selected section
  const [selectedBankIndex, setSelectedBankIndex] = useState(null); // Store selected bank index
  const [selectedSectionIndex, setSelectedSectionIndex] = useState(null);
  const [filteredQuestions, setFilteredQuestions] = useState([]);

  const [selectedSection, setSelectedSection] = useState(null);
  const location = useLocation();

  const isActive = (path) => location.pathname === path;

  // Add testInfo object
  const testInfo = {
    marks: 100,
    noOfQuestions: 50,
    negativeMarks: -0.25,
    duration: "2h",
  };

  const questionBanks = [
    {
      id: 1,
      name: "Questionbank-1",
      questions: [ // General questions for the entire question bank
        {
          id: 1,
          question: "What is React?",
          answer: "React is a JavaScript library for building UIs.",
          type: "truefalse",
          marks: 1,
          owner: "Admin",
        },
        {
          id: 2,
          question: "What is JSX?",
          answer: "JSX is a syntax extension for JavaScript, used with React.",
          type: "shortanswer",
          marks: 2,
          owner: "Admin",
        },
        {
          id: 3,
          question: "What is Virtual DOM?",
          answer: "Virtual DOM is an in-memory representation of the real DOM elements.",
          type: "shortanswer",
          marks: 2,
          owner: "Admin",
        },
      ],
      sections: [
        {
          name: "QB-1 Tag 1",
          questions: [
            {
              id: 4,
              question: "What are React Hooks?",
              answer:
                "Hooks are functions that let you use state and lifecycle features in functional components.",
              type: "longanswer",
              marks: 5,
              owner: "Admin",
            },
            {
              id: 5,
              question: "Explain useState Hook.",
              answer:
                "useState is a Hook that lets you add state to functional components.",
              type: "shortanswer",
              marks: 3,
              owner: "Admin",
            },
          ],
        },
        {
          name: "QB-1 Tag 2",
          questions: [
            {
              id: 6,
              question: "What is a Component?",
              answer: "A Component is a reusable piece of UI in React.",
              type: "shortanswer",
              marks: 2,
              owner: "Admin",
            },
            {
              id: 7,
              question: "What is useEffect Hook?",
              answer: "useEffect is a React Hook for side effects in functional components.",
              type: "longanswer",
              marks: 4,
              owner: "Admin",
            },
          ],
        },
        {
          name: "QB-1 Tag 3",
          questions: [
            {
              id: 8,
              question: "What is State in React?",
              answer: "State is a JavaScript object that stores dynamic data for a component.",
              type: "shortanswer",
              marks: 2,
              owner: "Admin",
            },
          ],
        },
        {
          name: "QB-1 :Tag 4",
          questions: [
            {
              id: 9,
              question: "What is Props?",
              answer:
                "Props are read-only properties passed from a parent component to a child component.",
              type: "shortanswer",
              marks: 2,
              owner: "Admin",
            },
          ],
        },
      ],
    },
    {
      id: 2,
      name: "Questionbank-2",
      questions: [
        {
          id: 1,
          question: "What is JavaScript?",
          answer: "JavaScript is a programming language for web development.",
          type: "shortanswer",
          marks: 2,
          owner: "Teacher1",
        },
        {
          id: 2,
          question: "What is ES6?",
          answer: "ES6 is the 6th version of ECMAScript, with features like let/const, arrow functions, and classes.",
          type: "shortanswer",
          marks: 3,
          owner: "Teacher1",
        },
        {
          id: 3,
          question: "Explain closures in JavaScript.",
          answer: "Closures allow a function to access variables from its outer scope even after the outer function has returned.",
          type: "longanswer",
          marks: 5,
          owner: "Teacher1",
        },
        {
          id: 4,
          question: "What is a promise in JavaScript?",
          answer: "A promise is an object that represents the eventual completion (or failure) of an asynchronous operation.",
          type: "longanswer",
          marks: 5,
          owner: "Teacher1",
        },
      ],
      sections: [
        {
          name: "QB-2 : Tag 5",
          questions: [
            {
              id: 5,
              question: "What is an event loop in JavaScript?",
              answer: "The event loop is a mechanism that handles asynchronous operations in JavaScript.",
              type: "shortanswer",
              marks: 3,
              owner: "Teacher1",
            },
            {
              id: 6,
              question: "Explain setTimeout and setInterval.",
              answer: "setTimeout executes a function after a delay, while setInterval repeatedly executes a function at a fixed interval.",
              type: "longanswer",
              marks: 4,
              owner: "Teacher1",
            },
          ],
        },
        {
          name: "QB-2 : Tag 1",
          questions: [
            {
              id: 7,
              question: "What is the difference between var, let, and const?",
              answer: "var is function-scoped, while let and const are block-scoped. const cannot be reassigned.",
              type: "shortanswer",
              marks: 3,
              owner: "Teacher1",
            },
            {
              id: 8,
              question: "What are arrow functions in JavaScript?",
              answer: "Arrow functions are a concise syntax for writing functions and do not have their own `this`.",
              type: "shortanswer",
              marks: 3,
              owner: "Teacher1",
            },
          ],
        },
        {
          name: "QB-2 : Tag 2",
          questions: [
            {
              id: 9,
              question: "Explain async/await in JavaScript.",
              answer: "async/await is a syntactic sugar for promises, making asynchronous code easier to read and write.",
              type: "longanswer",
              marks: 5,
              owner: "Teacher1",
            },
          ],
        },
        {
          name: "QB-2 : Tag 3",
          questions: [
            {
              id: 10,
              question: "What is JSON?",
              answer: "JSON (JavaScript Object Notation) is a lightweight data interchange format.",
              type: "shortanswer",
              marks: 2,
              owner: "Teacher1",
            },
          ],
        },
      ],
    },

  ];
  const [selectedBank, setSelectedBank] = useState(null)
  const [isSectionsDropdownOpen, setIsSectionsDropdownOpen] = useState(false)

  const toggleQuestionBankDropdown = () => {
    setIsQuestionBankDropdownOpen(!isQuestionBankDropdownOpen);
    setIsSectionsDropdownOpen(false); // Close sections dropdown when toggling the question bank dropdown
  };
  const toggleSectionsDropdown = () => {
    setIsSectionsDropdownOpen(!isSectionsDropdownOpen);
  };
  const handleBankSelect = (bankIndex) => {
    const selectedBank = questionBanks[bankIndex];
    setSelectedBank(selectedBank);
    setSelectedSection(null);
    setQuestionsToShow(selectedBank.questions); // Show general questions
    setIsQuestionBankDropdownOpen(false);
    setIsSectionsDropdownOpen(true);
  };

  const handleSectionSelect = (sectionIndex) => {
    const selectedSection = selectedBank.sections[sectionIndex];
    setSelectedSection(selectedSection);
    setQuestionsToShow(selectedSection.questions); // Show section-specific questions
    setIsSectionsDropdownOpen(false);
  };

  const questionBankDropdownRef = useRef(null);
  const sectionsDropdownRef = useRef(null);


  // Handle click outside to close dropdowns
  useEffect(() => {
    const handleClickOutside = (event) => {
      // Close Question Bank dropdown if clicked outside
      if (
        questionBankDropdownRef.current &&
        !questionBankDropdownRef.current.contains(event.target)
      ) {
        setIsQuestionBankDropdownOpen(false);
      }

      // Close Sections dropdown if clicked outside
      if (
        sectionsDropdownRef.current &&
        !sectionsDropdownRef.current.contains(event.target)
      ) {
        setIsSectionsDropdownOpen(false);
      }
    };

    // Add event listener
    document.addEventListener('mousedown', handleClickOutside);

    // Cleanup event listener
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);
  const dropdownRef = useRef(null);


  // Handle outside click
  useEffect(() => {
    function handleClickOutside(event) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsDropdownOpen(false);
      }
    }

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);



  // const handleBankSelect = (bankIndex) => {
  //   setSelectedBankIndex(bankIndex);
  //   setSelectedSectionIndex(null); 
  //   setFilteredQuestions([]); 

  //   const selectedBank = questionBanks[bankIndex];
  //   setQuestionsToShow(selectedBank.questions);
  // };


  // Define toggleDropdown function
  const toggleDropdown = () => {
    setIsDropdownOpen(!isDropdownOpen);
  };

  return (
    <div className="test-sidebar-container">

      <div className="testquestionadd-sidebar-buttons">
        {/* New Question Button */}
        <div className='d-flex justify-content-center'>
          <button className=" allbuttons">New Question</button>
        </div>

        <div className='w-100 d-flex justify-content-center'>
          <div className="testquestionadd-dropdown-container">
            {/* Question Bank Dropdown */}
            <div className="dropdown-wrapper" ref={questionBankDropdownRef}>
              <button className="section-dropdown" onClick={toggleQuestionBankDropdown}>
                {selectedBank ? selectedBank.name : "Add From QB"}
              </button>
              {isQuestionBankDropdownOpen && (
                <div className="dropdown-style qb-dropdown">
                  {questionBanks.map((bank, bankIndex) => (
                    <button
                      key={bank.id}
                      className="testquestionadd-dropdown-item"
                      onClick={() => {
                        handleBankSelect(bankIndex);
                        setSelectedSection(null);
                        setIsSectionsDropdownOpen(false);
                      }}
                    >
                      {bank.name}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Sections Dropdown */}
            {selectedBank && (
              <div className="dropdown-wrapper" ref={sectionsDropdownRef}>
                <button className="section-dropdown" onClick={toggleSectionsDropdown}>
                  {selectedSection ? selectedSection.name : "Select Tag"}
                </button>
                {isSectionsDropdownOpen && (
                  <div className="dropdown-style">
                    {selectedBank.sections.map((section, index) => (
                      <button
                        key={index}
                        className="testquestionadd-dropdown-item"
                        onClick={() => handleSectionSelect(index)}
                      >
                        {section.name}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>


        </div>

        {/* Section View Button */}
        {/* <button className="allbuttons">
          View
        </button> */}
      </div>
      {/* Section View Button */}
      {/* <button className="allbuttons">
          View
        </button> */}


      <hr />

      <div className="testquestionadd-marks-section my-4">
        {/* Selected Count */}
        <div className="testquestionadd-input-container">
          <label>Selected</label>
          <div className="counter-box">{marks || 0}</div>
        </div>

        {/* Total Marks */}
        <div className="testquestionadd-input-container">
          <label>Total Mark</label>
          <div className="counter-box">{marks || 0}</div>
        </div>

        {/* Negative Marks (per question) */}
        <div className="testquestionadd-input-container">
          <label>Negative Mark (per question)</label>
          <div className="counter-box" style={{ marginTop: "-19px" }}>
            {negativeMarks || 0}
          </div>
        </div>
      </div>


      {/* Dropdown for Sections */}
      <div className='w-100 d-flex flex-column align-items-center'>
        <div className="testquestionadd-container">
          <button
            className={`allbuttons dropdown-button ${isDropdownOpen ? "open" : ""}`}
            onClick={toggleDropdown}
          >
            Add to Section
          </button>

          {isDropdownOpen && (
            <div className="dropdown-style" ref={dropdownRef}>
              <div className="testquestionadd-dropdown-item">Tag 1</div>
              <div className="testquestionadd-dropdown-item">Tag 2</div>
              <div className="testquestionadd-dropdown-item">Tag 3</div>
              <div className="testquestionadd-dropdown-item">Tag 4</div>
            </div>
          )}
        </div>

        {/* Add to Test Button */}
        <button className="allbuttons">Add to Test</button>
      </div>

      <hr />

      {/* Test Information */}
      <h3 className="sidebar-contents-header">Test Information</h3>
      <ul className=" test-sidebar-menu">
      <li>
        <Link to="#" className={`sidebar-contents ${isActive("") ? "active" : ""}`}>
          <AiOutlineFileDone className="icon" />
          <span className="sidebar-letters">Marks : (10)</span>
        </Link>
      </li>
      <li>
        <Link to="#" className={`sidebar-contents ${isActive("") ? "active" : ""}`}>
          <MdPlaylistAddCheck className="icon" />
          <span className="sidebar-letters">No. of Q : (10)</span>
        </Link>
      </li>
      <li>
        <Link to="#" className={`sidebar-contents ${isActive("") ? "active" : ""}`}>
          <MdExposureNeg1 className="icon" />
          <span className="sidebar-letters">Neg : (10)</span>
        </Link>
      </li>
      <li>
        <Link to="#" className={`sidebar-contents ${isActive("") ? "active" : ""}`}>
          <Clock size={16} />

          <span className="sidebar-letters">Duration : (10)</span>
        </Link>
      </li>
</ul>
      <hr />
    </div>
  );
};

export default TestQuestionAddSidebar;
