import React, { useState, useRef, useEffect } from "react";
import DispatchModal from "../DispatchModal/DispatchModal";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { FaTrashAlt, } from "react-icons/fa";
import { RiInboxUnarchiveFill } from "react-icons/ri";
import ShareModal from "../ShareModal/ShareModal";
import { Link } from "react-router-dom";
import DataTable from "../../../ReusableComponents/TableComponent/TableComponent";
import PaginationButtons from "../../../ReusableComponents/Pagination/PaginationButton";
import PaginationInfo from "../../../ReusableComponents/Pagination/PaginationInfo";

const data = [
  { id: 1, test: "Test 1", owner: "John Doe", status: "Published", lastModified: "2days ago by You" },
  { id: 2, test: "Test 2", owner: "Jane Smith", status: "notpublished", lastModified: "1month ago by You" },

];
const mockScheduledTests = [
  { date: "2025-01-05", time: "10:30 AM" },
  { date: "2025-01-06", time: "2:00 PM" },
]
const Archived = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);


  const [emails, setEmails] = useState([]);

  const [showTagOptions, setShowTagOptions] = useState(false);
  const [showMoreOptions, setShowMoreOptions] = useState(false);
   const [rowsPerPage, setRowsPerPage] = useState(5); // Set the number of rows per page
    const [currentPage, setCurrentPage] = useState(1);


  const tagOptionsRef = useRef(null);
  const moreOptionsRef = useRef(null);

  useEffect(() => {
    const handleClickOutside = (event) => {
      // If click is outside the tag options, close it
      if (tagOptionsRef.current && !tagOptionsRef.current.contains(event.target)) {
        setShowTagOptions(false);
      }

      // If click is outside the more options, close it
      if (moreOptionsRef.current && !moreOptionsRef.current.contains(event.target)) {
        setShowMoreOptions(false);
      }
    };

    // Add event listener to detect outside clicks
    document.addEventListener("mousedown", handleClickOutside);

    // Cleanup event listener when the component unmounts
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  const [showButtons, setShowButtons] = useState(true);


  const paginatedData = data.slice(0, rowsPerPage);

  const loadMore = () => {
    setRowsPerPage((prevRows) => {
      const newRows = prevRows + 5;
      if (newRows >= data.length) setShowButtons(false); // Hide buttons if all data is shown
      return newRows;
    });
  };


  const fullView = () => {
    setRowsPerPage(data.length); // Show all data
    setShowButtons(false); // Hide buttons after Full View
  };


  const columns = [
    {
      name: (
        <div>
          Test Names
        </div>
      ),
      selector: "test",
      sortable: false,
      cell: (row) => (
        <div style={{ display: "flex", alignItems: "center" }}>
          <Link to={`/test/${row.id}/movetest`} state={{ testName: row.test, testId: row.id }}>
            <span className="row-link">{row.test}</span>
          </Link>
        </div>
      ),
    },
    {
      name: (
        <div>
          Owner
        </div>
      ),
      selector: "owner",
      sortable: false, // This column is sortable
    },
    {
      name: (
        <div >
          Status
        </div>
      ),
      selector: "status",
      sortable: false,
    },
    {
      name: (
        <div>
          Last Modified
        </div>
      ),
      selector: "lastModified",
      sortable: false, // This column is sortable
    },
    {
      name: "Actions",
      cell: (row) => (
        <div className="test-action-buttons">
          <button className="test-action-button archive" aria-label="Archive">
            <RiInboxUnarchiveFill />
            <span className="tooltip-text">Un Archive</span>
          </button>
          <button className="test-action-button copy" aria-label="Copy">
            <FaTrashAlt />
            <span className="tooltip-text">delete</span>
          </button>

          {/* <button className="test-action-button delete" aria-label="Delete">
            <FaTrashAlt />
            <span className="tooltip-text">Delete</span>
          </button> */}
        </div>
      ),
    },
  ];


  return (
    <div className="test-index-wrapper">
      <div className="test-index-container">
        <div className="test-index-header">
          <h1 className="breadcrumb">Archived</h1>
        </div>

        <div className="my-data-table">
          <DataTable
            columns={columns}
            data={data} 
            availableActions={["delete", "download", "tag"]}
            />
            
        </div>


        <ShareModal
          isOpen={isShareModalOpen} // Correct state variable
          onClose={() => setIsShareModalOpen(false)}
          emails={emails}
          setEmails={setEmails}
        />

        <DispatchModal
          isOpen={isModalOpen}
          onClose={() => setIsModalOpen(false)}
          scheduledTests={mockScheduledTests}
        />

      </div>

      <PaginationButtons
        filteredQuestions={data}
        rowsPerPage={rowsPerPage}
        currentPage={currentPage}
        loadMore={loadMore}
        fullView={fullView}
      />

      <PaginationInfo
        filteredQuestions={data}
        rowsPerPage={rowsPerPage}
        currentPage={currentPage}
        label="Tests"
      />


    </div>
  );
};

export default Archived;
