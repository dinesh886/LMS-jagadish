import React, { useState, useRef, useEffect } from "react";
import DispatchModal from "../DispatchModal/DispatchModal";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";

import {
  FaPaperPlane,
  FaCopy,
  FaFilePdf,
  FaArchive,
  FaTrashAlt,
  FaSearch,
  FaTrash,
  FaShare,
  FaTag,
  FaEllipsisH,
  FaDownload,
  FaPlus,
  FaCheck,
  FaTimes,
  FaArrowUp,
  FaArrowDown
} from "react-icons/fa";

import ShareModal from "../ShareModal/ShareModal";
import { Link } from "react-router-dom";
import DataTable from "../../../ReusableComponents/TableComponent/TableComponent";
import PaginationButtons from "../../../ReusableComponents/Pagination/PaginationButton";
import PaginationInfo from "../../../ReusableComponents/Pagination/PaginationInfo";

const data = [
  { id: 1, test: "Test 1", owner: "John Doe", status: "Published", lastModified: "2days ago by You" },
  { id: 2, test: "Test 2", owner: "Jane Smith", status: "notpublished", lastModified: "1month ago by You" },
]

const mockScheduledTests = [
  { date: "2025-01-05", time: "10:30 AM" },
  { date: "2025-01-06", time: "2:00 PM" },
];
const SharedWithMe = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);

  const [searchTerm, setSearchTerm] = useState("");
  const [filteredData, setFilteredData] = useState(data);
  const [emails, setEmails] = useState([]);
  const [selectedRows, setSelectedRows] = useState([]);
  const [tags, setTags] = useState(["Urgent", "Review", "Completed"]);
  const tagColors = {
    "Urgent": "#FF0000", // Red
    "Review": "#FF9900", // Orange
    "Completed": "#008000", // Green
  };
  const [newTag, setNewTag] = useState("");
  const [tagColor, setTagColor] = useState("#ff0000"); // Default color for the tag
  const [isTagModalOpen, setIsTagModalOpen] = useState(false);
  const [showTagOptions, setShowTagOptions] = useState(false);
  const [showMoreOptions, setShowMoreOptions] = useState(false);
  const [rowsPerPage, setRowsPerPage] = useState(5);
  const [currentPage, setCurrentPage] = useState(1);
  const [isCustomColor, setIsCustomColor] = useState(false);
  const [customColor, setCustomColor] = useState("#000000");
  const [sortColumn, setSortColumn] = useState(null); // To track which column is being sorted
  const [isAscending, setIsAscending] = useState(true); // To track the sorting order (ascending or descending)
  const [tooltipVisible, setTooltipVisible] = useState(false);
  console.log("ShareModal isOpen: ", isShareModalOpen);
  console.log("tag modal", isTagModalOpen);
   const [showButtons, setShowButtons] = useState(true);


  const defaultColors = [
    "#FF5733", "#33FF57", "#3357FF", "#FF33A6", "#33FFEC",
    "#F7FF33", "#FF9633", "#9B33FF", "#33A6FF", "#FF5733"
  ];

  const tagOptionsRef = useRef(null);
  const moreOptionsRef = useRef(null);

  const paginatedData = data.slice(0, rowsPerPage);

  const loadMore = () => {
    setRowsPerPage((prevRows) => {
      const newRows = prevRows + 5;
      if (newRows >= data.length) setShowButtons(false); // Hide buttons if all data is shown
      return newRows;
    });
  };

  
  const fullView = () => {
    setRowsPerPage(data.length); // Show all data
    setShowButtons(false); // Hide buttons after Full View
  };

  useEffect(() => {
    const handleClickOutside = (event) => {
      // If click is outside the tag options, close it
      if (tagOptionsRef.current && !tagOptionsRef.current.contains(event.target)) {
        setShowTagOptions(false);
      }

      // If click is outside the more options, close it
      if (moreOptionsRef.current && !moreOptionsRef.current.contains(event.target)) {
        setShowMoreOptions(false);
      }
    };

    // Add event listener to detect outside clicks
    document.addEventListener("mousedown", handleClickOutside);

    // Cleanup event listener when the component unmounts
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);


  const handleCreateClick = () => {
    if (!newTag.trim()) {
      setTooltipVisible(true);
    } else {
      handleAddTag();
      setIsTagModalOpen(false);  // Close modal after creating
    }
  }
  const handleSort = (column) => {
    // Toggle sorting order if the same column is clicked
    const newIsAscending = sortColumn === column ? !isAscending : true;

    setSortColumn(column); // Set the column being sorted
    setIsAscending(newIsAscending); // Set the sorting order

    // Sorting logic with null/undefined and type safety
    const sortedData = [...filteredData].sort((a, b) => {
      // Get values for the current column, fall back to empty string if undefined/null
      const valueA = a[column] !== undefined && a[column] !== null ? a[column] : '';
      const valueB = b[column] !== undefined && b[column] !== null ? b[column] : '';

      // Compare values based on the data type
      if (typeof valueA === "string" && typeof valueB === "string") {
        // String comparison
        return newIsAscending
          ? valueA.localeCompare(valueB)
          : valueB.localeCompare(valueA);
      } else if (typeof valueA === "number" && typeof valueB === "number") {
        // Numeric comparison
        return newIsAscending ? valueA - valueB : valueB - valueA;
      } else if (valueA instanceof Date && valueB instanceof Date) {
        // Date comparison
        return newIsAscending ? valueA - valueB : valueB - valueA;
      }

      // Default case: return 0 if not comparable (e.g., different types)
      return 0;
    });

    setFilteredData(sortedData); // Update the filtered data with sorted data
  };
  const handleSearch = (event) => {
    const value = event.target.value.toLowerCase();
    setSearchTerm(value);
    const filtered = data.filter(
      (item) =>
        item.test.toLowerCase().includes(value) ||
        item.owner.toLowerCase().includes(value) ||
        item.lastModified.includes(value)
    );
    setFilteredData(filtered);
  };

  const handleSelectAll = (event) => {
    if (event.target.checked) {
      setSelectedRows(filteredData.map((row) => row.id)); // Select all visible rows
    } else {
      setSelectedRows([]); // Deselect all rows
    }
  };

  const handleRowSelect = (id) => {
    if (selectedRows.includes(id)) {
      setSelectedRows(selectedRows.filter((rowId) => rowId !== id)); // Deselect row
    } else {
      setSelectedRows([...selectedRows, id]); // Select row
    }
  };

  const showMoreOptionsButton = selectedRows.length > 1; // Show 'More' button only when multiple rows are selected

  const handleAddTag = () => {
    if (newTag.trim()) {
      setTags([...tags, { name: newTag, color: tagColor }]);
      setNewTag("");
      setTagColor("#ff0000"); // Reset the color picker
      setIsTagModalOpen(false); // Close the modal
    }
  };

  const columns = [
    {
      name: (
          <div className="flex items-center">
            <span>Test Names</span>
          </div>
      ),
      selector:"test",
      cell: (row) => (
        <div style={{ display: "flex", alignItems: "center" }}>
          
          <Link to={`/test/${row.id}/movetest`} state={{ testName: row.test, testId: row.id }}>
            <span className="row-link">{row.test}</span>
          </Link>
        </div>
      ),
    },
    {
      name: (
        <div className="cursor-pointer">
          Status
        </div>
      ),
      selector: "status",
      sortable: false,
    },
    {
      name: (
        <div className="cursor-pointer">
          Last Modified
        </div>
      ),
      selector: "lastModified",
      sortable: false, // This column is sortable
    },
    {
      name: "Actions",
      selector: "actions",
      cell: (row) => (
        <div className="test-action-buttons">
          <button className="test-action-button copy" aria-label="Copy">
            <FaCopy />
            <span className="tooltip-text">Copy</span>
          </button>
          <button className="test-action-button pdf" aria-label="Download PDF">
            <FaFilePdf />
            <span className="tooltip-text">Download PDF</span>
          </button>
          <button className="test-action-button archive" aria-label="Archive">
            <FaArchive />
            <span className="tooltip-text">Archive</span>
          </button>
         
        </div>
      ),
      width: "250px",
      style: {
        justifyContent: "flex-end",
      },
    },

  ];


  return (
    <div className="test-index-wrapper">
      <div className="test-index-container">
        <div className="test-index-header">
          <h1 className="breadcrumb">Shared With Me</h1>
          <div className="test-index-actions">
          </div>
        </div>

        <div className="my-data-table">
          <DataTable
            columns={columns}
            data={paginatedData}
            availableActions={["delete", "download", "tag"]}
          />
        </div>

        <ShareModal
          isOpen={isShareModalOpen} // Correct state variable
          onClose={() => setIsShareModalOpen(false)}
          emails={emails}
          setEmails={setEmails}
        />

        <DispatchModal
          isOpen={isModalOpen}
          onClose={() => setIsModalOpen(false)}
          scheduledTests={mockScheduledTests}
        />
      </div>

      <PaginationButtons
        filteredQuestions={data}
        rowsPerPage={rowsPerPage}
        currentPage={currentPage}
        loadMore={loadMore}
        fullView={fullView}
      />

      <PaginationInfo
        filteredQuestions={data}
        rowsPerPage={rowsPerPage}
        currentPage={currentPage}
        label="Tests"
      />
      
    </div>
  );
};

export default SharedWithMe;
