import React, { useState, useRef, useEffect } from "react";
import DispatchModal from "../DispatchModal/DispatchModal";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";

import {
  FaTrashRestore,
  RiInboxUnarchiveFill,
  FaPaperPlane,
  FaCopy,
  FaFilePdf,
  FaArchive,
  FaTrashAlt,
  FaSearch,
  FaTrash,
  FaShare,
  FaTag,
  FaEllipsisH,
  FaDownload,
  FaPlus,
  FaCheck,
  FaRegWindowRestore,
  FaArrowUp,
  FaArrowDown,
  FaUndo,
  FaTimes,
} from "react-icons/fa";

import ShareModal from "../ShareModal/ShareModal";
import { Link } from "react-router-dom";
import TablePagination from "../../../../TablePagination";
import DataTable from "../../../ReusableComponents/TableComponent/TableComponent";
import PaginationButtons from "../../../ReusableComponents/Pagination/PaginationButton";
import PaginationInfo from "../../../ReusableComponents/Pagination/PaginationInfo";

const data = [
  { id: 1, test: "Test 1", owner: "John Doe", status: "Published", lastModified: "2 days ago by You" },
  { id: 2, test: "Test 2", owner: "Jane Smith", status: "Not published", lastModified: "1 month ago by You" },

];
const mockScheduledTests = [
  { date: "2025-01-05", time: "10:30 AM" },
  { date: "2025-01-06", time: "2:00 PM" },
]
const Trashed = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);


  const [emails, setEmails] = useState([]);

  const [isTagModalOpen, setIsTagModalOpen] = useState(false);
  const [showTagOptions, setShowTagOptions] = useState(false);
  const [showMoreOptions, setShowMoreOptions] = useState(false);
  const [rowsPerPage, setRowsPerPage] = useState(5);
  const [currentPage, setCurrentPage] = useState(1);

  console.log("ShareModal isOpen: ", isShareModalOpen);
  console.log("tag modal", isTagModalOpen);

  // Functions to handle Restore and Delete actions
  const handleRestore = (row) => {
    console.log("Restore action for:", row);

  };

  const handleDelete = (row) => {
    console.log("Delete action for:", row);

  };


  const tagOptionsRef = useRef(null);
  const moreOptionsRef = useRef(null);
  useEffect(() => {
    const handleClickOutside = (event) => {
      // If click is outside the tag options, close it
      if (tagOptionsRef.current && !tagOptionsRef.current.contains(event.target)) {
        setShowTagOptions(false);
      }

      // If click is outside the more options, close it
      if (moreOptionsRef.current && !moreOptionsRef.current.contains(event.target)) {
        setShowMoreOptions(false);
      }
    };

    // Add event listener to detect outside clicks
    document.addEventListener("mousedown", handleClickOutside);

    // Cleanup event listener when the component unmounts
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  const [showButtons, setShowButtons] = useState(true);


  const paginatedData = data.slice(0, rowsPerPage);

  const loadMore = () => {
    setRowsPerPage((prevRows) => {
      const newRows = prevRows + 5;
      if (newRows >= data.length) setShowButtons(false); // Hide buttons if all data is shown
      return newRows;
    });
  };


  const fullView = () => {
    setRowsPerPage(data.length); // Show all data
    setShowButtons(false); // Hide buttons after Full View
  };




  const columns = [
    {
      name: (
        <div>
          Test Names
        </div>
      ),
      selector: "test",
      sortable: false,
      cell: (row) => (
        <div>
          <Link to={`/test/${row.id}/movetest`} state={{ testName: row.test, testId: row.id }}>
            <span className="row-link">{row.test}</span>
          </Link>
        </div>
      ),
    },

    {
      name: (
        <div>
          Owner
        </div>
      ),
      selector: "owner",
      sortable: false, // This column is sortable
    },
    {
      name: (
        <div>
          Status
        </div>
      ),
      selector: "status",
      sortable: false,
    },
    {
      name: (
        <div>
          Last Modified
        </div>
      ),
      selector: "lastModified",
      sortable: false, // This column is sortable
    },
    {
      name: "Actions",
      cell: (row) => (
        <div className="test-action-buttons">
          {/* Restore Button */}
          <button
            className="test-action-button restore"
            aria-label="Restore"
            onClick={() => handleRestore(row)} // Define this function
          >
            <FaUndo />
            <span className="tooltip-text">Restore</span>
          </button>

          {/* Delete Button */}
          <button
            className="test-action-button delete"
            aria-label="Delete"
            onClick={() => handleDelete(row)} // Define this function
          >
            <FaTrashAlt />
            <span className="tooltip-text">Delete</span>
          </button>
        </div>
      ),
    },
  ];

  return (
    <div className="test-index-wrapper">
      <div className="test-index-container">
        <div className="test-index-header">
          <h1 className="breadcrumb">Trashed</h1>

        </div>

        <div className="my-data-table">

          <DataTable
            columns={columns}
            data={data}
            availableActions={["delete", "download", "tag"]}
          />

        </div>
        
        <ShareModal
          isOpen={isShareModalOpen} // Correct state variable
          onClose={() => setIsShareModalOpen(false)}
          emails={emails}
          setEmails={setEmails}
        />

        <DispatchModal
          isOpen={isModalOpen}
          onClose={() => setIsModalOpen(false)}
          scheduledTests={mockScheduledTests}
        />
      </div>
      <PaginationButtons
        filteredQuestions={data}
        rowsPerPage={rowsPerPage}
        currentPage={currentPage}
        loadMore={loadMore}
        fullView={fullView}
      />

      <PaginationInfo
        filteredQuestions={data}
        rowsPerPage={rowsPerPage}
        currentPage={currentPage}
        label="Tests"
      />

    </div>
  );

}

export default Trashed