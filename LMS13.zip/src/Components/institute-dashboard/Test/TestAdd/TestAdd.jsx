import React, { useState, useEffect, useRef } from "react";

import { useParams, useNavigate, Link, useLocation } from "react-router-dom";
import TopBar from "../../class-batch/classtopbar/classtopbar";
import {
  FaArrowLeft, FaPlus, FaEdit, FaTrash, FaCopy, FaSearch,
  FaPlusSquare, FaTrashAlt, FaArrowRight, FaCheck
} from "react-icons/fa";
import Modal from "react-modal";
import './TestAdd.css'
import { Pagination } from "@mui/material";
import AddTagsComponent from "../../../ReusableComponents/AddTagsComponent/AddTagsComponent";
import DataTable from "../../../ReusableComponents/TableComponent/TableComponent";
import PaginationButtons from "../../../ReusableComponents/Pagination/PaginationButton";
import PaginationInfo from "../../../ReusableComponents/Pagination/PaginationInfo";
import ColumnVisibilityDropdown from "../../../ReusableComponents/ColumnVisibilityDropdown/ColumnVisibilityDropdown";

const TestAdd = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const location = useLocation();
  const testName = location.state?.testName || "Unknown Test";

  const data = [
    {
      id: 1,
      question: "What is the primary purpose of React in web development, and how does it contribute to building dynamic and interactive user interfaces?",
      answer: "React is primarily used for building user interfaces, allowing developers to create reusable UI components and manage the state of applications efficiently.",
      type: "Mcq",
      marks: 5,
      owner: "Admin",
      options: ["A JavaScript library", "A programming language", "A database", "A framework"],
      correctAnswer: "A JavaScript library"
    },
    {
      id: 2,
      question: "What is the result of 5 + 3?",
      answer: "8",
      type: "Numerical",
      marks: 2,
      owner: "Admin"
    },
    {
      id: 3,
      question: "Is React a JavaScript library?",
      answer: "True",
      type: "True/False",
      marks: 1,
      owner: "Admin"
    },
    {
      id: 4,
      question: "Explain the concept of JSX in React.",
      answer: "JSX is a syntax extension for JavaScript that looks similar to XML, used to define UI components in React.",
      type: "Descriptive",
      marks: 5,
      owner: "Admin"
    },

    {
      id: 20,
      question: "What is the primary purpose of React in web development, and how does it contribute to building dynamic and interactive user interfaces?",
      answer: "React is primarily used for building user interfaces, allowing developers to create reusable UI components and manage the state of applications efficiently.",
      type: "Mcq",
      marks: 5,
      owner: "Admin",
      options: ["A JavaScript library", "A programming language", "A database", "A framework"],
      correctAnswer: "A JavaScript library"
    },
    {
      id: 21,
      question: "What is the primary purpose of React in web development, and how does it contribute to building dynamic and interactive user interfaces?",
      answer: "React is primarily used for building user interfaces, allowing developers to create reusable UI components and manage the state of applications efficiently.",
      type: "Mcq",
      marks: 5,
      owner: "Admin",
      options: ["A JavaScript library", "A programming language", "A database", "A framework"],
      correctAnswer: "A JavaScript library"
    },
  ];

  // State declarations
  const [questionsByBank, setQuestionsByBank] = useState({ 1: data });
  const [questions, setQuestions] = useState(data);
  const [currentPage, setCurrentPage] = useState(1);
  const [questionsPerPage, setQuestionsPerPage] = useState(5);
  const [selectedQuestionIds, setSelectedQuestionIds] = useState([]);
  const [selectedQuestion, setSelectedQuestion] = useState(null);
  const [modalIsOpen, setModalIsOpen] = useState(false);
  const [isSelectAllChecked, setIsSelectAllChecked] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [filterType, setFilterType] = useState("");
  const [questionIndex, setQuestionIndex] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(5);
  const [filteredData, setFilteredData] = useState(data);
  const [searchTerm, setSearchTerm] = useState("");
  const currentQuestions = questionsByBank[id] || [];
  const [selectedRows, setSelectedRows] = useState([]);
  const [showTagOptions, setShowTagOptions] = useState(false);
  const [showMoreOptions, setShowMoreOptions] = useState(false);

  const [sortColumn, setSortColumn] = useState(null);
  const [isAscending, setIsAscending] = useState(true);
  const [isDropdownOpen, setDropdownOpen] = useState(false);
  

  const [fullViewMode, setFullViewMode] = useState(false);
  const [allRowsExpanded, setAllRowsExpanded] = useState(false);
  const [showButtons, setShowButtons] = useState(true);
  const [showFullViewButton, setShowFullViewButton] = useState(true);
  const [expandedRows, setExpandedRows] = useState([]);

  // Filter questions based on search and type
  const filteredQuestions = currentQuestions.filter((question) => {
    const matchesSearchQuery = question.question.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesFilterType = filterType ? question.type === filterType : true;
    return matchesSearchQuery && matchesFilterType;
  });

  // Pagination functions
  const loadMore = () => {
    const newRows = rowsPerPage + 10;
    setRowsPerPage(newRows);

    if (newRows >= data.length) {
      setShowButtons(false);
    }
  };

  const toggleFullView = () => {
    if (!fullViewMode) {
      // Enter Full View mode
      setRowsPerPage(data.length);
      setAllRowsExpanded(true);
      setShowFullViewButton(false);
      setShowButtons(false);
    } else {
      // Exit Full View mode
      setAllRowsExpanded(false);
      setShowFullViewButton(true);
      setShowButtons(true);
    }
    setFullViewMode(!fullViewMode);
  };
  // Question navigation functions
  const handleNextQuestion = () => {
    if (questionIndex < filteredQuestions.length - 1) {
      const nextIndex = questionIndex + 1;
      setQuestionIndex(nextIndex);
      setSelectedQuestion(filteredQuestions[nextIndex]);
    }
  };

  const handlePrevQuestion = () => {
    if (questionIndex > 0) {
      const prevIndex = questionIndex - 1;
      setQuestionIndex(prevIndex);
      setSelectedQuestion(filteredQuestions[prevIndex]);
    }
  };

  // Question CRUD operations
  const handleAddQuestion = () => {
    console.log("Add question");
    // Implementation for adding a question
  };

  const handleEditQuestion = (questionId) => {
    console.log("Edit question", questionId);
    // Implementation for editing a question
  };

  const handlemoveQuestion = (questionId) => {
    console.log("move question", questionId);
    // Implementation for moving a question
  };

  const handleDeleteQuestion = () => {
    console.log("Delete selected questions", selectedQuestionIds);
    // Implementation for deleting questions
  };

  const handleCopyQuestion = () => {
    console.log("Copy selected questions", selectedQuestionIds);
    // Implementation for copying questions
  };

  const handleSetMarks = (questionId) => {
    console.log("Set marks for question", questionId);
    // Implementation for setting marks
  };

  // Column visibility management
  const [columns, setColumns] = useState([
    {
      name: "Questions",
      selector: "question",
      cell: (row) => (
        <div className={`flex items-center`}>
          <span className={`row-link ${fullViewMode ? "" : "truncate"}`}>
            {row.question}
          </span>
        </div>
      ),
      isVisible: true,
    },
    {
      name: "Owner",
      selector: "owner",
      isVisible: false,
    },
    {
      name: "Type",
      selector: "type",
      isVisible: false,
    },
    {
      name: "Marks",
      selector: "marks",
      isVisible: false,
    },
    {
      name: "Actions",
      selector: "actions",
      isVisible: false,
      cell: (row) => (
        <div className="test-action-buttons flex gap-2">
          <button
            className="test-action-button copy"
            aria-label="Copy"
            onClick={(e) => {
              e.stopPropagation();
              handleCopyQuestion(row.id);
            }}
          >
            <FaCopy />
            <span className="tooltip-text">Copy</span>
          </button>
          <button
            className="test-action-button edit"
            aria-label="Edit"
            onClick={(e) => {
              e.stopPropagation();
              handleEditQuestion(row.id);
            }}
          >
            <FaEdit />
            <span className="tooltip-text">Edit</span>
          </button>
          <button
            className="test-action-button delete"
            aria-label="Delete"
            onClick={(e) => {
              e.stopPropagation();
              handleDeleteQuestion(row.id);
            }}
          >
            <FaTrashAlt />
            <span className="tooltip-text">Delete</span>
          </button>
          <button
            className="test-action-button add-to-test"
            aria-label="Move to Test"
            onClick={(e) => {
              e.stopPropagation();
              handlemoveQuestion(row.id);
            }}
          >
            <FaArrowRight />
            <span className="tooltip-text">Move to Test</span>
          </button>
          <button
            className="test-action-button set-mark"
            aria-label="Set Mark"
            onClick={(e) => {
              e.stopPropagation();
              handleSetMarks(row.id);
            }}
          >
            <span className="mark-symbol">M</span>
            <span className="tooltip-text">Set Mark</span>
          </button>
        </div>
      ),
    },
  ]);

  // Toggle column visibility
  const toggleColumnVisibility = (columnSelector) => {
    setColumns((prevColumns) =>
      prevColumns.map((column) =>
        column.selector === columnSelector
          ? { ...column, isVisible: !column.isVisible }
          : column
      )
    );
  };

  // Filter visible columns
  const visibleColumns = columns.filter((column) => column.isVisible);

  // Click outside handler for dropdowns
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (!event.target.closest(".testadd-column-dropdown")) {
        setDropdownOpen(false);
      }
    };

    document.addEventListener("click", handleClickOutside);
    return () => {
      document.removeEventListener("click", handleClickOutside);
    };
  }, []);

  return (
    <div className="testadd-index-wrapper">
      <div className="testadd-index-container">
        <div className="">
          <div className="d-flex justify-content-between w-100">
            <div>
              <h3 className="breadcrumb"> Test {id} Questions</h3>
            </div>
            <div className="columnvisibility-wrapper">
              <ColumnVisibilityDropdown
                columns={columns}
                onToggleColumn={toggleColumnVisibility}
              />
            </div>
          </div>

          {filteredQuestions.length === 0 ? (
            <div className="empty-state">
              <p>No questions found for this Test {id}.</p>
            </div>
          ) : (
            <>
              <div className="my-data-table">
                  <DataTable
                    columns={visibleColumns}
                    data={fullViewMode ? data : data.slice(0, rowsPerPage)}
                    enableToggle={true}
                    fullViewMode={fullViewMode}
                    allRowsExpanded={allRowsExpanded}
                    onToggleAllRows={toggleFullView}
                    expandedRows={expandedRows}
                    setExpandedRows={setExpandedRows}
                  />
              </div>
            </>
          )}
        </div>
      </div>

      {(showButtons || (fullViewMode && !allRowsExpanded)) && (
        <>
          <PaginationButtons
            filteredQuestions={data}
            rowsPerPage={rowsPerPage}
            currentPage={currentPage}
            loadMore={loadMore}
            toggleFullView={toggleFullView}
            fullViewMode={fullViewMode}
            showFullViewButton={showFullViewButton}
          />
          <PaginationInfo
            filteredQuestions={data}
            rowsPerPage={rowsPerPage}
            currentPage={currentPage}
            label="Questions"
          />
        </>
      )}
      {/* Modal for question details */}
      <Modal
        isOpen={modalIsOpen}
        onRequestClose={() => setModalIsOpen(false)}
        className="modal-content"
        overlayClassName="modal-overlay"
      >
        {/* Modal content implementation */}
      </Modal>
    </div>
  );
};

export default TestAdd;