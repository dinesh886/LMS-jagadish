import React, { useState, useRef, useEffect } from "react";
import DispatchModal from "../DispatchModal/DispatchModal";
import {
  FaPaperPlane,
  FaCopy,
  FaFilePdf,
  FaArchive,
  FaTrashAlt,
  FaSearch,
  FaTrash,
  FaShare,
  FaTag,
  FaEllipsisH,
  FaDownload,
  FaPlus,
  FaCheck,
  FaTimes,
  FaChevronDown,
  FaArrowUp

} from "react-icons/fa";
import "./TestIndex.css";
import ShareModal from "../../../ReusableComponents/TestShareModal/ShareModal";
import { Link } from "react-router-dom";
import TestSidebar from "../TestSidebar/TestSidebar";
import DataTable from "../../../ReusableComponents/TableComponent/TableComponent";
import PaginationButtons from "../../../ReusableComponents/Pagination/PaginationButton";
import PaginationInfo from "../../../ReusableComponents/Pagination/PaginationInfo";
import PublishModal from "../../../ReusableComponents/PublishModal/PublishModal";

const data = [
  { id: 1, test: "Test 1", owner: "John Doe", status: "Published", lastModified: "2 days ago by You" },
  { id: 2, test: "Test 2", owner: "Jane Smith", status: "Not Published", lastModified: "1 month ago by You" },
  { id: 3, test: "Test 3", owner: "Mark Johnson", status: "Published", lastModified: "5 days ago by You" },
  { id: 4, test: "Test 4", owner: "Mark Johnson", status: "Published", lastModified: "30 minutes ago by You" },
  { id: 5, test: "Test 5", owner: "Mark Johnson", status: "Not Published", lastModified: "2 months ago by You" },
  { id: 6, test: "Test 6", owner: "Mark Johnson", status: "Published", lastModified: "1 day ago by You" },
  { id: 7, test: "Test 7", owner: "Mark Johnson", status: "Published", lastModified: "1 day ago by You" },
  { id: 8, test: "Test 8", owner: "Mark Johnson", status: "Published", lastModified: "1 day ago by You" },
  { id: 9, test: "Test 9", owner: "Mark Johnson", status: "Published", lastModified: "1 day ago by You" },
  { id: 10, test: "Test 10", owner: "Mark Johnson", status: "Published", lastModified: "1 day ago by You" },
  { id: 11, test: "Test 11", owner: "Mark Johnson", status: "Published", lastModified: "1 day ago by You" },
  { id: 12, test: "Test 12", owner: "Mark Johnson", status: "Published", lastModified: "1 day ago by You" },
];

const mockScheduledTests = [
  { date: "2025-01-05", time: "10:30 AM", testName: "Math Quiz", owner: "John Doe" },
  { date: "2025-01-06", time: "2:00 PM", testName: "Science Test", owner: "Jane Smith" },
];


const TestIndex = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);

  const [emails, setEmails] = useState([]);
  const [selectedRows, setSelectedRows] = useState([]);

  const [tagColor, setTagColor] = useState("#ff0000"); // Default color for the tag
  const [isTagModalOpen, setIsTagModalOpen] = useState(false);
  const [showTagOptions, setShowTagOptions] = useState(false);

  const [rowsPerPage, setRowsPerPage] = useState(5); // Set the number of rows per page
  const [currentPage, setCurrentPage] = useState(1);
  const [isCustomColor, setIsCustomColor] = useState(false);
  const [customColor, setCustomColor] = useState("#000000");
  const [tooltipVisible, setTooltipVisible] = useState(false);
  const [showButtons, setShowButtons] = useState(true);
  const [filteredData, setFilteredData] = useState([]);

  const [showMoreOptions, setShowMoreOptions] = useState(false)
  const [selectedTest, setSelectedTest] = useState(""); // Store the selected test name
  const [showTooltip, setShowTooltip] = useState(false)
  const [dataTableVisible, setDataTableVisible] = useState(false);


  const openModal = (testName) => {
    setSelectedTest(testName)
    setIsModalOpen(true)
  }

  const closeModal = () => {
    setIsModalOpen(false)
  }



  const handleOpenModal = (testName) => {
    setSelectedTest(testName); // Set selected test name
    setIsModalOpen(true); // Open the modal
  };

  const tagOptionsRef = useRef(null);
  const moreOptionsRef = useRef(null);

  useEffect(() => {
    const handleClickOutside = (event) => {
      // If click is outside the tag options, close it
      if (tagOptionsRef.current && !tagOptionsRef.current.contains(event.target)) {
        setShowTagOptions(false);
      }

      // If click is outside the more options, close it
      if (moreOptionsRef.current && !moreOptionsRef.current.contains(event.target)) {
        setShowMoreOptions(false);
      }
    };

    // Add event listener to detect outside clicks
    document.addEventListener("mousedown", handleClickOutside);

    // Cleanup event listener when the component unmounts
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);


  const openShareModal = (testName) => {
    setSelectedTest(testName);
    setIsShareModalOpen(true);
  };

  const paginatedData = data.slice(0, rowsPerPage);

  const loadMore = () => {
    setRowsPerPage((prevRows) => {
      const newRows = prevRows + 5;
      if (newRows >= data.length) setShowButtons(false); // Hide buttons if all data is shown
      return newRows;
    });
  };


  const fullView = () => {
    setRowsPerPage(data.length); // Show all data
    setShowButtons(false); // Hide buttons after Full View
  };


  const columns = [
    {
      name: (
        <div className="flex items-center">
          <span>Test Names</span>
        </div>
      ),
      selector: "test",
      cell: (row) => (
        <div className="flex items-center">
          <Link to={`/test/${row.id}/movetest`} state={{ testName: row.test, testId: row.id }}>
            <span className="row-link">{row.test}</span>
          </Link>
        </div>
      ),
    },
    {
      name: (
        <div className="cursor-pointer">
          Owner
        </div>
      ),
      selector: "owner",
      sortable: true,
    },
    {
      name: (
        <div className="cursor-pointer">
          Status
        </div>
      ),
      selector: "status",
      sortable: true,
    },
    {
      name: (
        <div className="cursor-pointer">
          Last Modified
        </div>
      ),
      selector: "lastModified",
      sortable: true,
    },
    {
      name: "Actions",
      selector: "actions",
      sortable: false, // Ensures sorting is disabled for this column
      cell: (row) => (
        <div className="test-action-buttons flex gap-2">
          <button
            className="test-action-button dispatch"
            aria-label="Dispatch"
            onClick={() => openModal((row.test))}
          >
            <FaPaperPlane />
            <span className="tooltip-text">Publish</span>
          </button>
          <button className="test-action-button copy" aria-label="Copy">
            <FaCopy />
            <span className="tooltip-text">Copy</span>
          </button>
          <button className="test-action-button pdf" aria-label="Download PDF">
            <FaFilePdf />
            <span className="tooltip-text">Download PDF</span>
          </button>
          <button
            className="test-action-button share"
            aria-label="Share"
            onClick={() => openShareModal(row.test)}
          >
            <FaShare />
            <span className="tooltip-text">Share</span>
          </button>
          <button className="test-action-button archive" aria-label="Archive">
            <FaArchive />
            <span className="tooltip-text">Archive</span>
          </button>
          <button className="test-action-button delete" aria-label="Delete">
            <FaTrashAlt />
            <span className="tooltip-text">Delete</span>
          </button>
        </div>
      ),
    },
  ];

  return (
    // TestIndex Component

    <div className="test-index-wrapper">
      <div className="test-index-container">
        <div className="test-index-header">
          <h1 className="breadcrumb">All Tests</h1>
        </div>

        <div className="my-data-table">
          <DataTable
            columns={columns}
            data={paginatedData}
            availableActions={["delete", "archive", "download", "tag", "more"]}
            enableToggle={false}
          />
        </div>

        {/* Other Modals */}
        <ShareModal
          isOpen={isShareModalOpen}
          onClose={() => setIsShareModalOpen(false)}
          emails={emails}
          setEmails={setEmails}
          testName={selectedTest}
        />
        {/* <DispatchModal
          isOpen={isModalOpen}
          onClose={() => setIsModalOpen(false)}
          scheduledTests={mockScheduledTests}
          selectedTest={selectedTest}
        /> */}
      </div>
      {/* <DispatchModal isOpen={isModalOpen} onClose={closeModal} selectedTest={selectedTest} /> */}
      <PublishModal isOpen={isModalOpen} onClose={closeModal} selectedTest={selectedTest} />
      <PaginationButtons
        filteredQuestions={data}
        rowsPerPage={rowsPerPage}
        currentPage={currentPage}
        loadMore={loadMore}
        fullView={fullView}
        isDataTableVisible={dataTableVisible} // <-- Pass true/false based on state
      />

      <PaginationInfo
        filteredQuestions={data}
        rowsPerPage={rowsPerPage}
        currentPage={currentPage}
        label="Tests"
      />

    </div>

  );
};

export default TestIndex;