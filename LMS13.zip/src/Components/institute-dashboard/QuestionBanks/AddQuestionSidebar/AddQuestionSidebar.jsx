import React, { useState, useEffect, useRef } from "react";
import { Link, useLocation, useParams } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { FaDatabase } from "react-icons/fa"; // Import the database icon
import { FaFolder } from "react-icons/fa"; // Import the folder icon
import { IoMdPricetag, } from "react-icons/io";
import AddTagsComponent from "../../../ReusableComponents/AddTagsComponent/AddTagsComponent";
import MCQModal from '../../../ReusableComponents/Questions-Types-Modals/MCQModal/MCQModal'
import NumericalModal from '../../../ReusableComponents/Questions-Types-Modals/NumericalModal/NumericalModal'
import TrueFalseModal from '../../../ReusableComponents/Questions-Types-Modals/TrueFalseModal/TrueFalseModal'
import DescriptiveModal from '../../../ReusableComponents/Questions-Types-Modals/DescriptiveModal/DescriptiveModal'
import {
  FaListOl,
  FaListUl,
  FaCalculator,
  FaCheckSquare,
  FaParagraph,
  FaTimes,
  FaTrash,
  FaTags,
  FaPlus,
  FaRegFolderOpen 

} from "react-icons/fa";
import AddFolderModal from "../../../ReusableComponents/AddFolderModal/AddFolderModal";
import TagActionsDropdown from "../../../ReusableComponents/TagActionsDropdown/TagActionsDropdown";
import ListOfQuestionsType from '../../../ReusableComponents/ListOfQuestionsType/ListOfQuestionsType'
const AddQuestionSidebar = () => {

  const { id } = useParams(); // ✅ Get id from URL
  const [folders, setFolders] = useState(() => {
    const storedFolders = localStorage.getItem("folders");
    return storedFolders ? JSON.parse(storedFolders) : [];
  });
  const [isFolderModalOpen, setIsFolderModalOpen] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false); // Modal state
  const [isNumericalModalOpen, setIsNumericalModalOpen] = useState(false);
  const [isTrueFalseModalOpen, setIsTrueFalseModalOpen] = useState(false);
  const [isDescriptiveModalOpen, setIsDescriptiveModalOpen] = useState(false);


  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const dropdownRef = useRef(null);
  const toggleDropdown = () => {
    setIsDropdownOpen((prev) => {
      console.log("Dropdown Open (before update):", prev);
      const newState = !prev;
      console.log("Dropdown Open (after update):", newState);
      return newState;
    });
  };

  const handleCloseDropdown = () => {
    console.log("Closing dropdown");
    setIsDropdownOpen(false);
  };

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        console.log("Clicked outside, closing dropdown");
        setIsDropdownOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);


  const [testName, setTestName] = useState(""); // Test name input value
  const [editingFolderId, setEditingFolderId] = useState(null);
  const [editedFolderName, setEditedFolderName] = useState("");
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [isTagModalOpen, setIsTagModalOpen] = useState(false);
  const [activeSection, setActiveSection] = useState("questionBank");
  const [showMoreOptions, setShowMoreOptions] = useState(false);
  const iconColors = ['#f44336', '#2196f3', '#ff9800', '#9c27b0']; // You can add more colors here
  const [tags, setTags] = useState(["Folder 1 (10)", "Folder 2 (20)"]); // Tags state
  const handleTagClick = (index) => {
    setShowMoreOptions(showMoreOptions === index ? null : index); // Toggle dropdown for the clicked tag
  };

  const handleAddFolder = ({ name, color }) => {
    console.log("New Folder Created:", { name, color });
    // Add your logic to save the folder
  };

  // Function to open the modal
  const handleOpenModal = () => {
    setIsModalOpen(true);
  };

  // Function to close the modal and reset input
  const handleCloseModal = () => {
    setIsModalOpen(false);
    setTestName(""); // Reset input field
  };

  // Function to handle test creation
  const handleCreateTest = () => {
    if (testName.trim() !== "") {
      console.log("New Test Created:", testName);
      // Add logic to save the test here
    }
    handleCloseModal();
  };
  const typeCounts = {
    "MCQ-1": 10,
    "MCQ-2": 5,
    Numerical: 3,
    "True/False": 7,
    Descriptive: 2,
  };
  const location = useLocation();
  const [activeTag, setActiveTag] = useState(""); // State to track active tag
  // Function to set active section
  const handleSetActive = (section) => {
    setActiveSection(section);
  };
  useEffect(() => {
    localStorage.setItem("folders", JSON.stringify(folders));
  }, [folders]);

  const addNewFolder = () => {
    const newFolder = {
      id: Date.now(),
      name: `New Folder ${folders.length + 1}`,
    };
    setFolders([...folders, newFolder]);
  };

  const startEditingFolder = (id, name) => {
    setEditingFolderId(id);
    setEditedFolderName(name);
  };

  const saveFolderName = (id) => {
    const updatedFolders = folders.map((folder) =>
      folder.id === id ? { ...folder, name: editedFolderName } : folder
    );
    setFolders(updatedFolders);
    setEditingFolderId(null);
    setEditedFolderName("");
  };

  const deleteFolder = (id) => {
    setFolders(folders.filter((folder) => folder.id !== id));
  };

  const toggleCollapse = () => {
    setIsCollapsed(!isCollapsed);
  };

  const toggleSection = (section) => {
    setActiveSection(activeSection === section ? null : section);
  };

  const isActive = (path) => location.pathname === path;
  

  return (
    <nav className="test-sidebar-container">
      <div>
        <div className="test-sidebar-header">
          <div className="w-100 d-flex justify-content-center">
            <div className="dropdown-container" ref={dropdownRef}>
              <button className="allbuttons" aria-label="Create New Test" onClick={() => {
                console.log("Button Clicked"); // Debugging
                toggleDropdown();
              }}>
                <span className="sidebar-letters">New Question</span>
              </button>


              {isDropdownOpen && (
                <div >
                  <ListOfQuestionsType onClose={() => setIsDropdownOpen(false)} />
                </div>
              )}


            </div>
          </div>

        </div>

        <div className="test-sidebar-section">
          {/* Unique Design Section */}
          {/* <div className="unique-design">
          <FontAwesomeIcon icon={faUserCircle} className="unique-icon" />
          <p className="unique-text d-flex">
            Manage your Question Bank efficiently!
          </p>
        </div> */}
          <ul className=" test-sidebar-menu">
          
        
            <li>
              <Link
                to={`/QuestionBank/Trashed/${id}/add`}  // ✅ Use dynamic id
                className={`sidebar-contents ${isActive(`/QuestionBank/Trashed/${id}/add`) ? "active" : ""}`}
              >
                <FaTrash className="icon" />
                <span className="sidebar-letters">Trashed</span>
              </Link>


            </li>
            <hr />
            <h3 className="sidebar-contents-header">All Types</h3>
            <li>
              <Link
                to="#"
                className={`sidebar-contents ${isActive("") ? "active" : ""}`}
              >
                <FaRegFolderOpen className="icon" />
            
                <span className="sidebar-letters">MCQ-1 (10)</span>
              </Link>
            </li>
            <li>
              <Link
                to="#"
                className={`sidebar-contents ${isActive("") ? "active" : ""}`}
              >
                <FaRegFolderOpen className="icon" />
                <span className="sidebar-letters">MCQ-2 (10)</span>
              </Link>
            </li>
            <li>
              <Link
                to="#"
                className={`sidebar-contents ${isActive("") ? "active" : ""}`}
              >
                <FaRegFolderOpen className="icon" />
                <span className="sidebar-letters">Numerical (10)</span>
              </Link>
            </li>
            <li>
              <Link
                to="#"
                className={`sidebar-contents ${isActive("") ? "active" : ""}`}
              >
                <FaRegFolderOpen className="icon" />
                <span className="sidebar-letters">True/False(10)</span>

              </Link>
            </li>
            <li>
              <Link
                to="#"
                className={`sidebar-contents ${isActive("") ? "active" : ""}`}
              >
                <FaRegFolderOpen className="icon" />
                <span className="sidebar-letters">Descriptive(10)</span>
              </Link>
            </li>
            <hr />
            <div className="sidebar-section">
              <button
                // onClick={handleOpenModal}
                className=" newtag"
                aria-label="Create New Test"
                onClick={() => setIsFolderModalOpen(true)}
              >
                <FaPlus className="icon" />
                <span className="sidebar-letters">New Category</span>
              </button>

              <ul className="test-sidebar-menu tags">
                {tags.map((tag, index) => (
                  <li key={index} className="tag-item">
                    <Link
                      // to={`/tag/${tag.toLowerCase()}`}
                      // below tag active code ${activeTag === tag ? "active" : ""}
                      className="sidebar-contents " // Check if tag is active
                      aria-label={`Tag: ${tag}`}
                    // onClick={() => handleSetActiveTag(tag)} 
                    >
                      <IoMdPricetag
                        className="icon"
                        style={{
                          color: iconColors[index % iconColors.length],
                          fontSize: "25px",
                        }}
                      />
                      <div className="w-100 d-flex justify-content-between align-items-center">
                        <span className="sidebar-letters">{tag}</span>

                        <button className="tag-button" >
                          <span className="tag-dropdown-toggle" onClick={() => handleTagClick(index)}></span>
                        </button>
                        {/* Dropdown */}
                        <TagActionsDropdown
                          isOpen={showMoreOptions === index}
                          onEdit={() => {
                            setIsFolderModalOpen(true)
                            setShowMoreOptions(null);
                          }}
                          onRemove={() => setShowMoreOptions(null)}
                          onClose={() => setShowMoreOptions(null)}
                        />
                      </div>
                    </Link>
                  </li>
                ))}
              </ul>

              <p className="sidebar-contents " style={{ fontStyle: "italic" }}> Uncategorized<span className="number">(5)</span></p>
            </div>
            {/* Tag Creation Modal */}
            <AddTagsComponent
              isOpen={isTagModalOpen}
              onClose={() => setIsTagModalOpen(false)}
            />



          </ul>




        </div>

      </div>
      <MCQModal open={isModalOpen} onClose={() => setIsModalOpen(false)} />
      <NumericalModal open={isNumericalModalOpen} onClose={() => setIsNumericalModalOpen(false)} />
      <TrueFalseModal open={isTrueFalseModalOpen} onClose={() => setIsTrueFalseModalOpen(false)} />
      <DescriptiveModal
        open={isDescriptiveModalOpen}
        onClose={() => setIsDescriptiveModalOpen(false)}
      />
      <AddFolderModal
        isOpen={isFolderModalOpen}
        onClose={() => setIsFolderModalOpen(false)}
        onAddFolder={handleAddFolder}
      />

    </nav>

  );
};

export default AddQuestionSidebar;
