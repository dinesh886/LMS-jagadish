import React, { useState, useEffect, useRef } from "react";
import { Link, useLocation } from "react-router-dom";
import { FaDatabase, FaFolder, FaPlus, FaFileAlt, FaArchive, FaTrash, FaTag } from "react-icons/fa";
import { IoMdPricetag } from "react-icons/io";
import AddTagsComponent from "../../../ReusableComponents/AddTagsComponent/AddTagsComponent";
import NewQBModal from "../../../ReusableComponents/NewQBModal/NewQBModal";
import AddFolderModal from "../../../ReusableComponents/AddFolderModal/AddFolderModal";
import TagActionsDropdown from "../../../ReusableComponents/TagActionsDropdown/TagActionsDropdown";
import "./Sidebar.css";

const Sidebar = ({ openModal }) => {
  const [folders, setFolders] = useState(() => {
    const storedFolders = localStorage.getItem("folders");
    return storedFolders ? JSON.parse(storedFolders) : [];
  });
   const [modalHeading, setModalHeading] = useState(""); // State for modal heading
     const [selectedSection, setSelectedSection] = useState(""); // State for selected section

  const [isQbModalOpen, setIsQbModalOpen] = useState(false);
  const [qbs, setQBs] = useState([]);
  const [isFolderModalOpen, setIsFolderModalOpen] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [testName, setTestName] = useState("");
  const [editingFolderId, setEditingFolderId] = useState(null);
  const [editedFolderName, setEditedFolderName] = useState("");
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [isTagModalOpen, setIsTagModalOpen] = useState(false);
  const [activeSection, setActiveSection] = useState("questionBank");
  const [tags, setTags] = useState(["Folder 1", "Folder 2"]);
  const [showMoreOptions, setShowMoreOptions] = useState(null);
  const [isNewTagModalOpen, setIsNewTagModalOpen] = useState(false);

  const iconColors = ['#f44336', '#2196f3', '#ff9800', '#9c27b0'];
  const dropdownRef = useRef(null);
  const toggleRef = useRef(null); // Ref for the toggle button

  // Use the useLocation hook to get the current location
  const location = useLocation();

  // Handle click on the tag button
  const handleTagClick = (index) => {
    setShowMoreOptions((prev) => (prev === index ? null : index));
  };


  // Handle click outside the dropdown
  const handleClickOutside = (event) => {
    if (
      dropdownRef.current &&
      !dropdownRef.current.contains(event.target) &&
      !toggleRef.current?.contains(event.target) // Check if the click is on the toggle button
    ) {
      setShowMoreOptions(null); // Close the dropdown if clicked outside
    }
  };

  useEffect(() => {
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  const handleAddFolder = ({ name, color }) => {
    console.log("New Folder Created:", { name, color });
    // Add your logic to save the folder
  };

  const handleCreateQB = (qbName) => {
    setQBs([...qbs, qbName]);
  };

  const addNewFolder = () => {
    const newFolder = {
      id: Date.now(),
      name: `New Folder ${folders.length + 1}`,
    };
    setFolders([...folders, newFolder]);
  };

  const startEditingFolder = (id, name) => {
    setEditingFolderId(id);
    setEditedFolderName(name);
  };

  const saveFolderName = (id) => {
    const updatedFolders = folders.map((folder) =>
      folder.id === id ? { ...folder, name: editedFolderName } : folder
    );
    setFolders(updatedFolders);
    setEditingFolderId(null);
    setEditedFolderName("");
  };

  const deleteFolder = (id) => {
    setFolders(folders.filter((folder) => folder.id !== id));
  };

  const toggleCollapse = () => {
    setIsCollapsed(!isCollapsed);
  };

  const toggleSection = (section) => {
    setActiveSection(activeSection === section ? null : section);
  };

  // Use the location object from useLocation
  const isActive = (path) => location.pathname === path;

  return (
    <nav className="test-sidebar-container">
      <div>
        <div className="test-sidebar-header">
          <div className="w-100 d-flex justify-content-center">
            <button
              onClick={() => setIsQbModalOpen(true)}
              className="allbuttons"
              aria-label="Create New Test"
            >
              <span className="sidebar-letters">New QB</span>
            </button>
          </div>
        </div>

        <div className="test-sidebar-section">
          <ul className="test-sidebar-menu">
            <li>
              <Link
                to="/Questionbank"
                className={`sidebar-contents ${isActive("/Questionbank") ? "active" : ""}`}
                aria-label="All Tests"
              >
                <FaFileAlt className="icon" />
                <span className="sidebar-letters">All QB</span>
              </Link>
            </li>

            <li>
              <Link
                to="/Questionbank/archived"
                className={`sidebar-contents ${isActive("/Questionbank/archived") ? "active" : ""}`}
              >
                <FaArchive className="icon" />
                <span className="sidebar-letters">Archived</span>
              </Link>
            </li>

            <li>
              <Link
                to="/Questionbank/Trashed"
                className={`sidebar-contents ${isActive("/Questionbank/Trashed") ? "active" : ""}`}
              >
                <FaTrash className="icon" />
                <span className="sidebar-letters">Trashed</span>
              </Link>
            </li>

            <hr />

            <div className="sidebar-section">
              <button
                className="newtag"
                aria-label="Create New Test"
                onClick={() => {
                  setIsFolderModalOpen(true);
                setModalHeading("New Folder");
              }}
              >
                <FaPlus className="icon" />
                <span className="sidebar-letters">New Folder</span>
              </button>
              <ul className="test-sidebar-menu tags">
                {tags.map((tag, index) => (
                  <li key={index} className="tag-item">
                    <Link className="sidebar-contents" aria-label={`Tag: ${tag}`}>
                      <IoMdPricetag
                        className="icon"
                        style={{
                          color: iconColors[index % iconColors.length],
                          fontSize: "25px",
                        }}
                      />
                      <div className="w-100 d-flex justify-content-between align-items-center">
                        <span className="sidebar-letters">{tag}</span>

                        {/* Toggle Button */}
                        <button className="tag-button" ref={toggleRef}>
                          <span
                            className="tag-dropdown-toggle"
                            onClick={() => handleTagClick(index)}
                          >
                    
                          </span>
                        </button>

                        {/* Dropdown */}
                        <TagActionsDropdown
                          isOpen={showMoreOptions === index}
                          onEdit={() => {
                            setIsFolderModalOpen(true);
                            setShowMoreOptions(null);
                            setModalHeading("Edit "); // Set the modal heading
                            setSelectedSection(tags[index]); // Set the selected section name
                          }}
                          onRemove={() => setShowMoreOptions(null)}
                          onClose={() => setShowMoreOptions(null)}
                        />
                      </div>
                    </Link>
                  </li>
                ))}
              </ul>
              <p className="sidebar-contents" style={{ fontStyle: "italic" }}>
                Uncategorized<span className="number">(5)</span>
              </p>
            </div>
          </ul>
        </div>
      </div>

      {/* Modals */}
      <NewQBModal
        isOpen={isQbModalOpen}
        onClose={() => setIsQbModalOpen(false)}
        onCreate={handleCreateQB}
      />
      <AddFolderModal
        isOpen={isFolderModalOpen}
        onClose={() => setIsFolderModalOpen(false)}
        onAddFolder={handleAddFolder}
        heading={modalHeading} // Pass the dynamic heading
        selectedSection={selectedSection} // Pass the selected section name
      />
      <AddTagsComponent
        isOpen={isTagModalOpen}
        onClose={() => setIsTagModalOpen(false)}
      />
    </nav>
  );
};

export default Sidebar;