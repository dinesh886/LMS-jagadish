import React, { useState } from "react";
import { Link } from "react-router-dom";
import DataTable from "../../../ReusableComponents/TableComponent/TableComponent";
import { FaCopy, FaEdit, FaTrashAlt, FaArrowRight, FaFolderPlus } from "react-icons/fa";
import PaginationButtons from "../../../ReusableComponents/Pagination/PaginationButton";
import PaginationInfo from "../../../ReusableComponents/Pagination/PaginationInfo";
import ColumnVisibilityDropdown from "../../../ReusableComponents/ColumnVisibilityDropdown/ColumnVisibilityDropdown";
import './QuestionsAdd.css';

const QuestionsAdd = () => {
  const data = [
    {
      id: 1,
      question: "What is the primary purpose of React in web development?",
      answer: "React is primarily used for building user interfaces.",
      modified: "2 days ago",
      created :"15/03/2025",
      type: "MCQ",
      section: "Section 1",
      marks: 5,
      owner: "Admin",
      options: ["A JavaScript library", "A programming language", "A database", "A framework"],
      correctAnswer: "A JavaScript library",
    },
    {
      id: 2,
      question: "Which company developed React?",
      answer: "React was developed by Facebook (now Meta).",
      modified: "5 days ago",
      created: "15/03/2025",
      type: "MCQ",
      section: "Section 1",
      marks: 5,
      owner: "Admin",
      options: ["Google", "Facebook", "Microsoft", "Apple"],
      correctAnswer: "Facebook",
    },
    {
      id: 3,
      question: "What is JSX in React?",
      answer: "JSX is a syntax extension for JavaScript used in React.",
      modified: "1 week ago",
      created: "15/03/2025",
      type: "MCQ",
      section: "Section 2",
      marks: 5,
      owner: "Admin",
      options: ["A templating engine", "A syntax extension", "A CSS framework", "A database"],
      correctAnswer: "A syntax extension",
    },
    {
      id: 4,
      question: "Which React hook is used to manage state in functional components?",
      answer: "useState is used to manage state in functional components.",
      modified: "3 days ago",
      created: "15/03/2025",
      type: "MCQ",
      section: "Section 2",
      marks: 5,
      owner: "Admin",
      options: ["useEffect", "useState", "useReducer", "useMemo"],
      correctAnswer: "useState",
    },
    {
      id: 5,
      question: "What does the useEffect hook do?",
      answer: "useEffect is used for handling side effects in React components.",
      modified: "4 days ago",
      created: "15/03/2025",
      type: "MCQ",
      section: "Section 3",
      marks: 5,
      owner: "Admin",
      options: ["Manages state", "Handles side effects", "Manipulates the DOM", "Creates new components"],
      correctAnswer: "Handles side effects",
    },
    {
      id: 6,
      question: "Which React feature helps improve performance by preventing unnecessary renders?",
      answer: "React.memo helps improve performance by preventing unnecessary renders.",
      modified: "6 days ago",
      created: "15/03/2025",
      type: "MCQ",
      section: "Section 3",
      marks: 5,
      owner: "Admin",
      options: ["React.lazy", "React.memo", "useCallback", "useEffect"],
      correctAnswer: "React.memo",
    },
    {
      id: 7,
      question: "What is the virtual DOM in React?",
      answer: "The virtual DOM is a lightweight copy of the real DOM used for efficient updates.",
      modified: "1 day ago",
      created: "15/03/2025",
      type: "MCQ",
      section: "Section 4",
      marks: 5,
      owner: "Admin",
      options: ["A database", "A JavaScript library", "A copy of the real DOM", "A CSS framework"],
      correctAnswer: "A copy of the real DOM",
    },
    {
      id: 8,
      question: "Which method is used to update the state in a React class component?",
      answer: "The setState() method is used to update state in class components.",
      modified: "2 days ago",
      created: "15/03/2025",
      type: "MCQ",
      section: "Section 4",
      marks: 5,
      owner: "Admin",
      options: ["this.state", "setState()", "updateState()", "changeState()"],
      correctAnswer: "setState()",
    },
    {
      id: 9,
      question: "What does the React Router library help with?",
      answer: "React Router helps in navigation and routing between components.",
      modified: "3 days ago",
      created: "15/03/2025",
      type: "MCQ",
      section: "Section 5",
      marks: 5,
      owner: "Admin",
      options: ["State management", "Styling components", "Routing and navigation", "Data fetching"],
      correctAnswer: "Routing and navigation",
    },
    {
      id: 10,
      question: "What is the correct way to pass props in React?",
      answer: "Props are passed to a component using attributes.",
      modified: "4 days ago",
      created: "15/03/2025",
      type: "MCQ",
      section: "Section 5",
      marks: 5,
      owner: "Admin",
      options: ["Using state", "Using attributes", "Using functions", "Using Redux"],
      correctAnswer: "Using attributes",
    },
  ];


  const [rowsPerPage, setRowsPerPage] = useState(5);
  const [showButtons, setShowButtons] = useState(true);
  const [currentPage, setCurrentPage] = useState(1);
  const [dataTableVisible, setDataTableVisible] = useState(false);
  const [expandedRow, setExpandedRow] = useState(null);
  // Define columns with visibility state
  const [columns, setColumns] = useState([
    {
      name: "Questions",
      selector: (row) => row?.question || "N/A", // Handle null values
      sortable: true, // ✅ Enable sorting
      cell: (row) => (
        <div className="flex items-center">
          {row?.id ? (
            <Link
              to={`/QuestionBank/${row.id}/add`}
              className={`row-link ${expandedRow === row.id ? "expanded" : ""}`}
              onClick={(e) => {
                e.preventDefault(); // Prevent navigation
                setExpandedRow(expandedRow === row.id ? null : row.id);
              }}
            >
              {row?.question || "No Question"}
            </Link>
          ) : (
            <span className="row-link">No Question</span>
          )}
        </div>
      ),


      isVisible: true,
    },

   
    {
      name: "Modified",
      selector: "modified",
      isVisible: false,
    },
    {
      name: "Created",
      selector: "created",
      isVisible: false,
    },
    {
      name: "Types",
      selector: "type",
      isVisible: false,
    },
    {
      name: "Sections",
      selector: "section",
      isVisible: false,
    },
    {
      name: "Actions",
      selector: "actions",
      isVisible: false,
      cell: (row) => (
        <div className="test-action-buttons flex gap-2">
          <button
            className="test-action-button copy"
            aria-label="Copy"
            onClick={(e) => {
              e.stopPropagation();
              // Handle copy action
            }}
          >
            <FaCopy />
            <span className="tooltip-text">Copy</span>
          </button>
          <button
            className="test-action-button edit"
            aria-label="Edit"
            onClick={(e) => {
              e.stopPropagation();
              // Handle edit action
            }}
          >
            <FaEdit />
            <span className="tooltip-text">Edit</span>
          </button>
          <button
                    className="test-action-button add-to-test"
                    aria-label="Move to Test"
                    onClick={(e) => {
                      e.stopPropagation();
                      // Handle move to test action
                    }}
                  >
                    <FaArrowRight /> {/* Use an arrow icon for "Move to Test" */}
                    <span className="tooltip-text">Move to Test</span>
                  </button>
          <button className="test-action-button copy" aria-label="Copy" onClick={(e) => {
            e.stopPropagation();
            // Handle move to test action
          }}>
                              <FaFolderPlus />
                              <span className="tooltip-text"> Add to section</span>
                            </button>
          <button
            className="test-action-button delete"
            aria-label="Delete"
            onClick={(e) => {
              e.stopPropagation();
              // Handle delete action
            }}
          >
            <FaTrashAlt />
            <span className="tooltip-text">Delete</span>
          </button>
        </div>
      ),
    },
  ]);

  // Toggle column visibility
  const toggleColumnVisibility = (columnSelector) => {
    setColumns((prevColumns) =>
      prevColumns.map((column) =>
        column.selector === columnSelector
          ? { ...column, isVisible: !column.isVisible }
          : column
      )
    );
  };

  // Filter visible columns
  const visibleColumns = columns.filter((column) => column.isVisible);

  return (
    <div className="questionsadd-index-wrapper">
      <div className="questionsadd-index-container">
        <div className="test-index-header">
          <h1 className="breadcrumb">QB 1 Questions</h1>
          <div className="columnvisibility-wrapper">
            <ColumnVisibilityDropdown
              columns={columns}
              onToggleColumn={toggleColumnVisibility}
            />
          </div>
        </div>

        <div className="my-data-table">
          <DataTable
            columns={visibleColumns}
            data={data.slice(0, rowsPerPage)}
            availableActions={["delete", "archive", "download", "tag"]}
            enableToggle={true}
          />
        </div>

      
      </div>
      <PaginationButtons
        filteredQuestions={data}
        rowsPerPage={rowsPerPage}
        currentPage={currentPage}
        loadMore={() => setRowsPerPage((prev) => prev + 5)}
        fullView={() => setRowsPerPage(data.length)}
        isDataTableVisible={dataTableVisible}
      />

      <PaginationInfo
        filteredQuestions={data}
        rowsPerPage={rowsPerPage}
        currentPage={currentPage}
        label="Tests"
      />
    </div>
  );
};

export default QuestionsAdd;