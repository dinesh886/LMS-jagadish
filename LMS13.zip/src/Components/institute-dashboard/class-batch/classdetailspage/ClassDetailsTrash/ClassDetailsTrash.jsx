
import DataTable from "../../../../ReusableComponents/TableComponent/TableComponent";
import React, { useState } from "react";
import { MdOutlineArchive } from "react-icons/md";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import PaginationButtons from "../../../../ReusableComponents/Pagination/PaginationButton";
import PaginationInfo from "../../../../ReusableComponents/Pagination/PaginationInfo";
import {
  FaPaperPlane,
  FaCopy,
  FaFilePdf,
  FaArchive,
  FaTrashAlt,

  FaCog, // Added settings icon
    FaEdit   // Rename icon
} from "react-icons/fa";

// import { FaArrowLeft, FaPlus, FaEdit, FaTrash, FaCopy } from "react-icons/fa";

import { Link } from "react-router-dom"; // Import Link for navigation

const ClassDetailsTrash = () => {
const data = [
    { id: 1, name: "Karthick", email: "karthick.k@gmail.com", joinDate: "16/06/2023", status: "active" },
    { id: 2, name: "Manikandan", email: "manikandan.r@gmail.com", joinDate: "20/06/2023", status: "inactive" },
    
  ];
  const [rowsPerPage, setRowsPerPage] = useState(5); // Set the number of rows per page
  const [showButtons, setShowButtons] = useState(true);
  const [currentPage, setCurrentPage] = useState(1);
  const [dataTableVisible, setDataTableVisible] = useState(false);
  const paginatedData = data.slice(0, rowsPerPage);
  const [searchTerm, setSearchTerm] = useState(""); // State to store search term
  const loadMore = () => {
    setRowsPerPage((prevRows) => {
      const newRows = prevRows + 5;
      if (newRows >= data.length) setShowButtons(false); // Hide buttons if all data is shown
      return newRows;
    });
  };


  const fullView = () => {
    setRowsPerPage(data.length); // Show all data
    setShowButtons(false); // Hide buttons after Full View
  };


 
  const columns = [
    {
      name: (
        <div className="flex items-center">
          <span>Student Names</span>
        </div>
      ),
      selector: "name", // Fixed selector to match data key
      cell: (row) => (
        <div className="flex items-center">
          <Link to={`/class/${row.id}/classdetailpage`}>
            <span className="row-link">{row.name}</span>
          </Link>
        </div>
      ),
    },
    {
      name: <div className="cursor-pointer">Student Emails</div>,
      selector: "email",
      sortable: true,
    },
    {
      name: <div className="cursor-pointer">Date Of Joining</div>,
      selector: "joinDate",
      sortable: true,
    },
    {
      name: <div className="cursor-pointer">Status</div>,
      selector: "status",
      sortable: true,
    },
   
    {
      name: "Actions",
      selector: "actions",
      sortable: false, // Disables sorting for actions
      cell: (row) => (
        <div className="test-action-buttons flex gap-2">
          
          <button className="test-action-button archive" aria-label="Archive">
            <FaArchive />
            <span className="tooltip-text">Active</span>
          </button>
          <button className="test-action-button delete" aria-label="Delete">
            <FaTrashAlt />
            <span className="tooltip-text">Delete</span>
          </button>
        </div>
      ),
    },
  ];
  return (
    <div className="test-index-wrapper">
      <div className="test-index-container">
        <div className="test-index-header">
          <h1 className="breadcrumb">  Class 1 Trashed Students</h1>
        </div>

        <div className="my-data-table">
          <DataTable
            columns={columns}
            data={paginatedData}
            availableActions={["delete", "archive", "download", "tag", "more"]}
            enableToggle={false}
          />
        </div>

        {/* Other Modals */}
        {/* <ShareModal
          isOpen={isShareModalOpen}
          onClose={() => setIsShareModalOpen(false)}
          emails={emails}
          setEmails={setEmails}
          testName={selectedTest}
        /> */}
        {/* <DispatchModal
          isOpen={isModalOpen}
          onClose={() => setIsModalOpen(false)}
          scheduledTests={mockScheduledTests}
          selectedTest={selectedTest}
        /> */}
      </div>
      {/* <DispatchModal isOpen={isModalOpen} onClose={closeModal} selectedTest={selectedTest} /> */}

      <PaginationButtons
        filteredQuestions={data}
        rowsPerPage={rowsPerPage}
        currentPage={currentPage}
        loadMore={loadMore}
        fullView={fullView}
        isDataTableVisible={dataTableVisible} // <-- Pass true/false based on state
      />

      <PaginationInfo
        filteredQuestions={data}
        rowsPerPage={rowsPerPage}
        currentPage={currentPage}
        label="Tests"
      />

    </div>
  );
};

export default ClassDetailsTrash