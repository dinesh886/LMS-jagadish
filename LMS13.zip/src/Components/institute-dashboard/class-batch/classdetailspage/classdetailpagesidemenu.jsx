import React, { useState, useEffect, useRef } from "react";
import { Link, useLocation } from "react-router-dom";
import { useParams } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { FaDatabase } from "react-icons/fa"; // Import the database icon
import { FaFolder } from "react-icons/fa"; // Import the folder icon
import { IoMdPricetag,  } from "react-icons/io";
import AddTagsComponent from "../../../ReusableComponents/AddTagsComponent/AddTagsComponent";
import AddStudentModal from '../../../ReusableComponents/AddStudentModal/AddStudentModal'
import NumericalModal from '../../../ReusableComponents/Questions-Types-Modals/NumericalModal/NumericalModal'
import {
  FaPlus,
  FaFileAlt,
  FaArchive,
  FaTrash,
  FaCheckCircle,  // ✅ Correct import
  FaTimesCircle,  // ✅ Correct import
  // Other icons...
} from "react-icons/fa";



const ClassDetailPageSideMenu = ({ 
  onShowActiveStudents, 
  onShowAllStudents, 
  onAddStudentClick, 
  onShowInActiveStudents, 
  archivedCount, 
  trashedCount 
}) => {
  const location = useLocation();
console.log(onAddStudentClick);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isAddStudentModalOpen, setIsAddStudentModalOpen] = useState(false);
  const [students, setStudents] = useState([]);
  const [isNumericalModalOpen, setIsNumericalModalOpen] = useState(false);
  const handleSaveStudent = (student) => {
    setStudents([...students, student]); // Add the new student to the list
  };
  const [testName, setTestName] = useState(""); // Test name input value
  const [editingFolderId, setEditingFolderId] = useState(null);
  const [editedFolderName, setEditedFolderName] = useState("");
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [isTagModalOpen, setIsTagModalOpen] = useState(false);
  const [activeSection, setActiveSection] = useState("questionBank");
  const [showMoreOptions, setShowMoreOptions] = useState(false);
  const iconColors = ['#f44336', '#2196f3', '#ff9800', '#9c27b0']; // You can add more colors here
  const [tags, setTags] = useState(["Folder 1", "Folder 2"]); // Tags state
  const handleTagClick = (index) => {
    setShowMoreOptions(showMoreOptions === index ? null : index); // Toggle dropdown for the clicked tag
  };
  const dropdownRef = useRef(null);
  const { id } = useParams();  // Get the dynamic ID
  const handleClickOutside = (event) => {
    if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
      setShowMoreOptions(null); // Close the dropdown if clicked outside
    }
  };
  // Function to open the modal
  const handleOpenModal = () => {
    setIsModalOpen(true);
  };

  // Function to close the modal and reset input
  const handleCloseModal = () => {
    setIsModalOpen(false);
    setTestName(""); // Reset input field
  };

  // Function to handle test creation
  const handleCreateTest = () => {
    if (testName.trim() !== "") {
      console.log("New Test Created:", testName);
      // Add logic to save the test here
    }
    handleCloseModal();
  };


  const [activeTag, setActiveTag] = useState(""); // State to track active tag
  // Function to set active section
  const handleSetActive = (section) => {
    setActiveSection(section);
  };
  // useEffect(() => {
  //   localStorage.setItem("folders", JSON.stringify(folders));
  // }, [folders]);

  // const addNewFolder = () => {
  //   const newFolder = {
  //     id: Date.now(),
  //     name: `New Folder ${folders.length + 1}`,
  //   };
  //   setFolders([...folders, newFolder]);
  // };

  const startEditingFolder = (id, name) => {
    setEditingFolderId(id);
    setEditedFolderName(name);
  };

  // const saveFolderName = (id) => {
  //   const updatedFolders = folders.map((folder) =>
  //     folder.id === id ? { ...folder, name: editedFolderName } : folder
  //   );
  //   setFolders(updatedFolders);
  //   setEditingFolderId(null);
  //   setEditedFolderName("");
  // };

  // const deleteFolder = (id) => {
  //   setFolders(folders.filter((folder) => folder.id !== id));
  // };

  const toggleCollapse = () => {
    setIsCollapsed(!isCollapsed);
  };

  const toggleSection = (section) => {
    setActiveSection(activeSection === section ? null : section);
  };

  const isActive = (path) => location.pathname === path;
  useEffect(() => {
    console.log("Modal Open State Changed:", isModalOpen);
  }, [isModalOpen]);



  return (
    <nav className="test-sidebar-container">
      <div >
        <div className="test-sidebar-header">
          <div className="w-100 d-flex justify-content-center">
            <button
              onClick={(event) => { event.preventDefault(); setIsAddStudentModalOpen(true); }}
              className=" allbuttons"
              aria-label="Create New Test"
            >
              {/* <FaPlus className="icon" /> */}
              <span className="sidebar-letters ">New Student</span>
            </button>

          </div>

        </div>

        <div className="test-sidebar-section">
          {/* Unique Design Section */}
          {/* <div className="unique-design">
          <FontAwesomeIcon icon={faUserCircle} className="unique-icon" />
          <p className="unique-text d-flex">
            Manage your Question Bank efficiently!
          </p>
        </div> */}
          <ul className="test-sidebar-menu">
            <li>
              <Link
                to={`/class/${id}/classdetailpage`}
                className={`sidebar-contents ${isActive("/class/allStudents") ? "active" : ""}`}
                aria-label="All Students"
              >
                <FaFileAlt className="icon" />
                <span className="sidebar-letters">All Students</span>
              </Link>
            </li>

            <li>
              <Link
                to="/class/activeStudents"
                className={`sidebar-contents ${isActive("/class/activeStudents") ? "active" : ""}`}
              >
                <FaCheckCircle className="icon" />
                <span className="sidebar-letters">Active Students</span>
              </Link>
            </li>

            <li>
              <Link
                to="/class/inactiveStudents"
                className={`sidebar-contents ${isActive("/class/inactiveStudents") ? "active" : ""}`}
              >
                <FaTimesCircle className="icon" />
                <span className="sidebar-letters">Inactive Students</span>
              </Link>
            </li>

            <hr />
            <li>
              <Link
                to={`/class/${id}/classdetailpage/archive`} // ✅ Corrected path
                className={`sidebar-contents ${isActive(`/class/${id}/classdetailpage/archive`) ? "active" : ""}`}
              >
                <FaArchive className="icon" />
                <span className="sidebar-letters">Archived</span>
              </Link>

            </li>

            <li>
              <Link
                to={`/class/${id}/classdetailpage/trash`} // ✅ Corrected path
                className={`sidebar-contents ${isActive(`/class/${id}/classdetailpage/trash`) ? "active" : ""}`}
              >
                <FaTrash className="icon" />
                <span className="sidebar-letters">Trashed</span>
              </Link>
            </li>


            <hr />

            {/* <div className="sidebar-section">
              <button
                className="newtag"
                aria-label="Create New Folder"
                onClick={() => setIsTagModalOpen(true)}
              >
                <FaPlus className="icon" />
                <span className="sidebar-letters">New Folder</span>
              </button>

              <ul className="test-sidebar-menu tags">
                {tags.map((tag, index) => (
                  <li key={index} className="tag-item">
                    <Link className="sidebar-contents">
                      <IoMdPricetag
                        className="icon"
                        style={{
                          color: iconColors[index % iconColors.length],
                          fontSize: "25px",
                        }}
                      />
                      <div className="w-100 d-flex justify-content-between align-items-center">
                        <span className="sidebar-letters">{tag}</span>

                        <button className="tag-button">
                          <span className="tag-dropdown-toggle" onClick={() => handleTagClick(index)}></span>
                        </button>
                        {showMoreOptions === index && (
                          <div className="tag-rename-options" ref={dropdownRef}>
                            <ul className="tag-list-dropdown">
                              <li className="testquestionadd-dropdown-item" onClick={() => setIsTagModalOpen(true)}>
                                Edit
                              </li>
                              <li className="testquestionadd-dropdown-item" onClick={() => setShowMoreOptions(null)}>
                                Remove
                              </li>
                            </ul>
                          </div>
                        )}
                      </div>
                    </Link>
                  </li>
                ))}
              </ul>

              <p className="sidebar-contents" style={{ fontStyle: "italic" }}>
                Uncategorized <span className="number">(5)</span>
              </p>
            </div> */}
          </ul>





        </div>

      </div>
      {/* Render the modal */}
      <AddStudentModal
        isOpen={isAddStudentModalOpen} onClose={() => setIsAddStudentModalOpen(false)} onSave={handleSaveStudent} />
    </nav>
  );
};

export default ClassDetailPageSideMenu;
