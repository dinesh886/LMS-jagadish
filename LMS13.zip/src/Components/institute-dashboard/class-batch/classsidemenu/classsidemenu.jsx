import React, { useState, useEffect, useRef } from "react";
import { Link, useLocation } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { FaDatabase } from "react-icons/fa"; // Import the database icon
import { FaFolder } from "react-icons/fa"; // Import the folder icon
import { IoMdPricetag,  } from "react-icons/io";
import AddTagsComponent from "../../../ReusableComponents/AddTagsComponent/AddTagsComponent";
import AddClassModal from "../../../ReusableComponents/AddClassModal/AddClassModal";
import AddFolderModal from "../../../ReusableComponents/AddFolderModal/AddFolderModal";
import TagActionsDropdown from "../../../ReusableComponents/TagActionsDropdown/TagActionsDropdown";
import {
  FaPlus,
  FaFileAlt,
  MdOutlinePublishedWithChanges,
  FaShare,
  FaPaperPlane,
  FaArchive,
  FaTrash,
  FaTag,
  FaChevronDown,
  FaChevronUp,
  FaCheck,
  FaTimes,
  FaArrowDown,
  FaArrowUp,


} from "react-icons/fa";



const ClassSideMenu = ({ archivedCount, trashedCount }) => {
  const [folders, setFolders] = useState(() => {
    const storedFolders = localStorage.getItem("folders");
    return storedFolders ? JSON.parse(storedFolders) : [];
  });
    const [isFolderModalOpen, setIsFolderModalOpen] = useState(false);
  const [isNewClassModalOpen, setIsNewClassModalOpen] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false); // Modal state
  const [testName, setTestName] = useState(""); // Test name input value
  const [editingFolderId, setEditingFolderId] = useState(null);
  const [editedFolderName, setEditedFolderName] = useState("");
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [isTagModalOpen, setIsTagModalOpen] = useState(false);
  const [activeSection, setActiveSection] = useState("questionBank");
  const [showMoreOptions, setShowMoreOptions] = useState(false);
  const iconColors = ['#f44336', '#2196f3', '#ff9800', '#9c27b0']; // You can add more colors here
  const [tags, setTags] = useState(["Folder 1", "Folder 2"]); // Tags state
  const handleTagClick = (index) => {
    setShowMoreOptions(showMoreOptions === index ? null : index); // Toggle dropdown for the clicked tag
  };

   const [modalHeading, setModalHeading] = useState(""); // State for modal heading
       const [selectedSection, setSelectedSection] = useState(""); // State for selected section
  
  const dropdownRef = useRef(null);

  const handleClickOutside = (event) => {
    if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
      setShowMoreOptions(null); // Close the dropdown if clicked outside
    }
  };
  // Function to open the modal
  const handleOpenModal = () => {
    setIsModalOpen(true);
  };
  const handleAddFolder = ({ name, color }) => {
    console.log("New Folder Created:", { name, color });
    // Add your logic to save the folder
  };
  // Function to close the modal and reset input
  const handleCloseModal = () => {
    setIsModalOpen(false);
    setTestName(""); // Reset input field
  };

  // Function to handle test creation
  const handleCreateTest = () => {
    if (testName.trim() !== "") {
      console.log("New Test Created:", testName);
      // Add logic to save the test here
    }
    handleCloseModal();
  };

  const location = useLocation();
  const [activeTag, setActiveTag] = useState(""); // State to track active tag
  // Function to set active section
  const handleSetActive = (section) => {
    setActiveSection(section);
  };
  useEffect(() => {
    localStorage.setItem("folders", JSON.stringify(folders));
  }, [folders]);

  const addNewFolder = () => {
    const newFolder = {
      id: Date.now(),
      name: `New Folder ${folders.length + 1}`,
    };
    setFolders([...folders, newFolder]);
  };

  const startEditingFolder = (id, name) => {
    setEditingFolderId(id);
    setEditedFolderName(name);
  };

  const saveFolderName = (id) => {
    const updatedFolders = folders.map((folder) =>
      folder.id === id ? { ...folder, name: editedFolderName } : folder
    );
    setFolders(updatedFolders);
    setEditingFolderId(null);
    setEditedFolderName("");
  };

  const deleteFolder = (id) => {
    setFolders(folders.filter((folder) => folder.id !== id));
  };

  const toggleCollapse = () => {
    setIsCollapsed(!isCollapsed);
  };

  const toggleSection = (section) => {
    setActiveSection(activeSection === section ? null : section);
  };

  const isActive = (path) => location.pathname === path;
  useEffect(() => {
    console.log("Modal Open State Changed:", isModalOpen);
  }, [isModalOpen]);
  return (
    <nav className="test-sidebar-container">
      <div >
        <div className="test-sidebar-header">
          <div className="w-100 d-flex justify-content-center">
            <Link to="/class/addclass">
              <button
                // onClick={() => setIsNewClassModalOpen(true)}
                className="allbuttons"
                aria-label="Create New Test"
              >
                {/* <FaPlus className="icon" /> */}
                <span className="sidebar-letters">New Class</span>
              </button>
            </Link>
   
          </div>

        </div>

        <div className="test-sidebar-section">
          {/* Unique Design Section */}
          {/* <div className="unique-design">
          <FontAwesomeIcon icon={faUserCircle} className="unique-icon" />
          <p className="unique-text d-flex">
            Manage your Question Bank efficiently!
          </p>
        </div> */}
          <ul className=" test-sidebar-menu">
            <li>
              <Link
                to="/class"
                className={`sidebar-contents ${isActive("/class") ? "active" : ""
                  }`}
                aria-label="All Tests"
              // onClick={() => handleSetActive("Alltest")}
              >
                <FaFileAlt className="icon" />
                <span className="sidebar-letters">All Classes</span>
              </Link>
            </li>

            <li> <Link
              to="/class/archivepage"
              className={`sidebar-contents ${isActive("/class/archivepage") ? "active" : ""
                }`}
            >

              <FaArchive className="icon" />
              <span className="sidebar-letters">Archived</span>
            </Link></li>

            <li> <Link
              to="/class/trashPage"
              className={`sidebar-contents ${isActive("/class/trashPage") ? "active" : ""
                }`}
            >
              <FaTrash className="icon" />
              <span className="sidebar-letters">Trashed</span>
            </Link></li>
            {/* Tag Creation Modal */}
            <AddTagsComponent
              isOpen={isTagModalOpen}
              onClose={() => setIsTagModalOpen(false)}
            />
            <hr />
            <div className="sidebar-section">
              <button
                // onClick={handleOpenModal}
                className=" newtag"
                aria-label="Create New Test"
                onClick={() => {
                  setIsFolderModalOpen(true);
                  setModalHeading("New Folder");



                }}
              >
                <FaPlus className="icon" />
                <span className="sidebar-letters">New Folder</span>
              </button>

              <ul className="test-sidebar-menu tags">
                {tags.map((tag, index) => (
                  <li key={index} className="tag-item">
                    <Link
                      // to={`/tag/${tag.toLowerCase()}`}
                      // below tag active code ${activeTag === tag ? "active" : ""}
                      className="sidebar-contents " // Check if tag is active
                      aria-label={`Tag: ${tag}`}
                    // onClick={() => handleSetActiveTag(tag)} 
                    >
                      <IoMdPricetag
                        className="icon"
                        style={{
                          color: iconColors[index % iconColors.length],
                          fontSize: "25px",
                        }}
                      />
                      <div className="w-100 d-flex justify-content-between align-items-center">
                        <span className="sidebar-letters">{tag}</span>

                        <button className="tag-button" >
                          <span className="tag-dropdown-toggle" onClick={() => handleTagClick(index)}></span>
                        </button>
                        {/* Dropdown */}
                        <TagActionsDropdown
                          isOpen={showMoreOptions === index}
                          onEdit={() => {
                            setIsFolderModalOpen(true)
                            setShowMoreOptions(null);
                            setModalHeading("Edit "); // Set the modal heading
                            setSelectedSection(tags[index]); // Set the selected section name
                          }}
                          onRemove={() => setShowMoreOptions(null)}
                          onClose={() => setShowMoreOptions(null)}
                        />
                      </div>
                    </Link>
                  </li>
                ))}
              </ul>

              <p className="sidebar-contents " style={{ fontStyle: "italic" }}> Uncategorized<span className="number">(5)</span></p>
            </div>

          </ul>




        </div>

      </div>
      <AddClassModal
        open={isNewClassModalOpen}
        onClose={() => setIsNewClassModalOpen(false)}
      />
      <AddFolderModal
        isOpen={isFolderModalOpen}
        onClose={() => setIsFolderModalOpen(false)}
        onAddFolder={handleAddFolder}
        heading={modalHeading} // Pass the dynamic heading
        selectedSection={selectedSection} // Pass the selected section name
      />
    </nav>
  );
};
export default ClassSideMenu;
