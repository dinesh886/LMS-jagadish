import React, { useState, useEffect, useRef } from "react";
import { FaArrowDown, FaArrowUp, FaSearch } from "react-icons/fa";
import "./TableComponent.css";
import BulkActions from "../BulkActions/BulkAction";
import ColumnVisibilityDropdown from "../ColumnDisability/columnDisability";

const DataTable = ({ 
  columns, 
  data, 
  tags, 
  availableActions = [], 
  enableToggle = false, 
  showColumnVisibility = false,
  fullViewMode = false 
}) => {
    const [selectedRows, setSelectedRows] = useState([]);
    const [sortColumn, setSortColumn] = useState(null);
    const [isAscending, setIsAscending] = useState(true);
    const [showTagOptions, setShowTagOptions] = useState(false);
    const [isTagModalOpen, setIsTagModalOpen] = useState(false);
    const [showMoreOptions, setShowMoreOptions] = useState(false);
    const [searchTerm, setSearchTerm] = useState("");
    const [filteredData, setFilteredData] = useState(data);
    const [expandedRows, setExpandedRows] = useState([]);

    const selectAllCheckboxRef = useRef();

    const handleSelectAll = (event) => {
        if (event.target.checked) {
            setSelectedRows(data.map((row) => row.id));
        } else {
            setSelectedRows([]);
        }
    };

    const handleRowSelect = (rowId) => {
        setSelectedRows((prevSelectedRows) =>
            prevSelectedRows.includes(rowId)
                ? prevSelectedRows.filter((id) => id !== rowId)
                : [...prevSelectedRows, rowId]
        );
    };

    useEffect(() => {
        if (selectAllCheckboxRef.current) {
            const isIndeterminate =
                selectedRows.length > 0 && selectedRows.length < data.length;
            selectAllCheckboxRef.current.indeterminate = isIndeterminate;
        }
    }, [selectedRows, data.length]);

    const handleSort = (column) => {
        const colDef = columns.find((col) => col.selector === column);
        if (!colDef || colDef.sortable === false) {
            return;
        }

        const ascending = sortColumn === column ? !isAscending : true;
        setSortColumn(column);
        setIsAscending(ascending);
    };

    const toggleRowExpansion = (rowId) => {
        if (fullViewMode) return;
        setExpandedRows((prev) =>
            prev.includes(rowId) ? prev.filter((id) => id !== rowId) : [...prev, rowId]
        );
    };

    useEffect(() => {
        const filtered = data.filter((row) =>
            Object.values(row).some((value) =>
                value && value.toString().toLowerCase().includes(searchTerm.toLowerCase())
            )
        );
        setFilteredData(filtered);
    }, [searchTerm, data]);

    const sortedData = [...filteredData].sort((a, b) => {
        if (!sortColumn) return 0;

        const aValue = a[sortColumn] ?? "";
        const bValue = b[sortColumn] ?? "";

        return isAscending
            ? aValue.toString().localeCompare(bValue.toString())
            : bValue.toString().localeCompare(aValue.toString());
    });

    const [selectedColumns, setSelectedColumns] = useState(
        columns.reduce((acc, col) => ({ ...acc, [col.selector]: true }), {})
    );

    const handleColumnVisibilityChange = (column, isVisible) => {
        setSelectedColumns((prev) => ({ ...prev, [column]: isVisible }));
    };

    return (
        <div className={fullViewMode ? "full-view" : ""}>
            <div className="test-index-actions">
                <div className="test-search-container mb-4 d-flex justify-content-between align-items-center">
                    <input
                        type="text"
                        placeholder="Search"
                        className="test-search-input"
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                    />
                    <FaSearch className="test-search-icon" />
                    {selectedRows.length > 0 && availableActions.length > 0 && (
                        <BulkActions
                            selectedRows={selectedRows}
                            tags={tags}
                            setShowTagOptions={setShowTagOptions}
                            setIsTagModalOpen={setIsTagModalOpen}
                            showMoreOptions={showMoreOptions}
                            setShowMoreOptions={setShowMoreOptions}
                            availableActions={availableActions}
                        />
                    )}
                </div>
            </div>
            <table className="custom-data-table">
                <thead>
                    <tr>
                        <th className="col-checkbox" >
                            <input
                                type="checkbox"
                                ref={selectAllCheckboxRef}
                                onChange={(e) => {
                                    e.stopPropagation();
                                    handleSelectAll(e);
                                }}
                                checked={selectedRows.length === data.length && data.length > 0}
                            />
                        </th>
                        {columns.map((col, colIndex) => (
                            <th
                                key={colIndex}
                                className={`col-${typeof col.name === "string" ? col.name.toLowerCase().replace(/\s+/g, '-') : 'default-column'}`}
                                style={{ width: col.width || "auto" }}
                            >
                                <div className="table-header-content" style={{ display: "flex", alignItems: "center" }}>
                                    <span
                                        style={{ display: "flex", alignItems: "center", cursor: col.selector ? "pointer" : "default" }}
                                        onClick={() => col.selector && handleSort(col.selector)}
                                    >
                                        {col.name}
                                        {sortColumn === col.selector &&
                                            (isAscending ? (
                                                <FaArrowUp className="sort-icon ml-2" />
                                            ) : (
                                                <FaArrowDown className="sort-icon ml-2" />
                                            ))}
                                    </span>
                                </div>
                            </th>
                        ))}
                    </tr>
                </thead>
                <tbody>
                    {sortedData.map((row) => (
                        <React.Fragment key={row.id}>
                            <tr 
                                onClick={() => enableToggle && toggleRowExpansion(row.id)}
                                className={`clickable-row ${selectedRows.includes(row.id) ? "checked-row" : ""} ${
                                    fullViewMode || expandedRows.includes(row.id) ? "expanded" : ""
                                }`}
                            >
                                <td className="col-checkbox" style={{ width: "50px" }}>
                                    <input
                                        type="checkbox"
                                        checked={selectedRows.includes(row.id)}
                                        onChange={(e) => {
                                            e.stopPropagation();
                                            handleRowSelect(row.id);
                                        }}
                                        onClick={(e) => e.stopPropagation()}
                                    />
                                </td>
                                {columns.map((col, colIndex) => (
                                    <td key={colIndex} className={`col-${typeof col.name === "string" ? col.name.toLowerCase().replace(/\s+/g, '-') : 'default-column'}`}>
                                        {col.cell ? col.cell(row) : row[col.selector]}
                                    </td>
                                ))}
                            </tr>
                            {enableToggle && (fullViewMode || expandedRows.includes(row.id)) && (
                                <tr className="expanded-row">
                                    <td colSpan={columns.length + 1}>
                                        <div className="expanded-content">
                                            <p className="answer"> {row.answer}</p>
                                        </div>
                                    </td>
                                </tr>
                            )}
                        </React.Fragment>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default DataTable;