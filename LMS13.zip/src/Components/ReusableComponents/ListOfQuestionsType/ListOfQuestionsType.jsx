import { useState } from "react";
import { Link } from "react-router-dom"; // Use this if you're using react-router-dom
import "./ListOfQuestionsType.css"; // Import the CSS file
import {
  FaListOl,
  FaListUl,
  FaCalculator,
  FaCheckSquare,
  FaParagraph,
  FaTimes,
  FaTrash,
  FaTags,
  FaPlus,
  FaRegFolderOpen 

} from "react-icons/fa";

import MCQModal from '../../ReusableComponents/Questions-Types-Modals/MCQModal/MCQModal'
import NumericalModal from '../../ReusableComponents/Questions-Types-Modals/NumericalModal/NumericalModal'
import TrueFalseModal from '../../ReusableComponents/Questions-Types-Modals/TrueFalseModal/TrueFalseModal'
import DescriptiveModal from '../../ReusableComponents/Questions-Types-Modals/DescriptiveModal/DescriptiveModal'
const ListOfQuestionsType = ({ onClose }) => {
      const [isModalOpen, setIsModalOpen] = useState(false); // Modal state
      const [isNumericalModalOpen, setIsNumericalModalOpen] = useState(false);
      const [isTrueFalseModalOpen, setIsTrueFalseModalOpen] = useState(false);
      const [isDescriptiveModalOpen, setIsDescriptiveModalOpen] = useState(false);
    return (
        <div className="questiontypes-dropdown-menu">
            <ul>
                <li>
                    <Link to="#" className="questiontypes-dropdown-item" onClick={(event) => {
                        event.preventDefault(); // Stops redirection
                        setIsModalOpen(true); // Opens the modal
                    }}>
                        <FaListOl className="icon" />
                        <span className="ps-2">MCQ-1</span> 
                    </Link>
                </li>
                <li>
                    <Link to="#" className="questiontypes-dropdown-item" onClick={(event) => {
                        event.preventDefault(); // Stops redirection
                        setIsModalOpen(true); // Opens the modal
                    }}>
                         <FaListOl className="icon" />
                        <span className="ps-2">MCQ-2</span> 
                    </Link>
                </li>
                <li>
                    <Link to="#" className="questiontypesdropdown-item" onClick={(event) => { event.preventDefault(); setIsNumericalModalOpen(true); }}>
                          <FaCalculator className="icon" />
                        <span className="ps-2">Numerical</span> 
                    </Link>
                </li>
                <li>
                    <Link to="#" className="questiontypes-dropdown-item" onClick={(event) => { event.preventDefault(); setIsTrueFalseModalOpen(true) }}>
                        <FaCheckSquare className="icon" />
                        <span className="ps-2">True/False</span> 
                    </Link>
                </li>
                <li>
                    <Link to="#" className="questiontypes-dropdown-item" onClick={(event) => { event.preventDefault(); setIsDescriptiveModalOpen(true) }}>
                        <FaParagraph className="icon" />
                        <span className="ps-2">Descriptive</span> 
                    </Link>
                </li>
            </ul>
            <MCQModal open={isModalOpen} onClose={() => setIsModalOpen(false)} />
            <NumericalModal open={isNumericalModalOpen} onClose={() => setIsNumericalModalOpen(false)} />
            <TrueFalseModal open={isTrueFalseModalOpen} onClose={() => setIsTrueFalseModalOpen(false)} />
            <DescriptiveModal
                open={isDescriptiveModalOpen}
                onClose={() => setIsDescriptiveModalOpen(false)}
            />
        </div>
    );
};

export default ListOfQuestionsType;