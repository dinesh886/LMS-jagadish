import React from "react";
import './PaginationButton.css'

const PaginationButtons = ({ filteredQuestions, rowsPerPage, currentPage, loadMore, fullView }) => {
  const hasMoreData = rowsPerPage * currentPage < filteredQuestions.length;

  return (
    
    <div className="pagination-buttons mt-4 d-flex justify-content-center">
      {hasMoreData && (
        <button
          className="load-more-button2"
          onClick={loadMore}
        >
          Load More
        </button>
      )}
      {hasMoreData && (
        <button
          className="full-view-button"
          onClick={fullView}
        >
          Full View
        </button>
      )}
    </div>
  );
};

export default PaginationButtons;
