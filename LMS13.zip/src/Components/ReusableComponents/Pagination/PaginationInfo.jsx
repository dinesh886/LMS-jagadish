import React from "react";
import './PaginationInfo.css'
const PaginationInfo = ({ filteredQuestions, rowsPerPage, currentPage, label }) => {
  if (filteredQuestions.length === 0) return null;

  return (
    <div className="pagination-info">
      Showing {Math.min(rowsPerPage * currentPage, filteredQuestions.length)} out of {filteredQuestions.length} {label}
    </div>
  );
};

export default PaginationInfo;
