import React from 'react';
import 'katex/dist/katex.min.css';
import { BlockMath, InlineMath } from 'react-katex';
import DOMPurify from 'dompurify';

const LatexRenderer = ({ content, isInline = false }) => {
    if (!content) return <div className="latex-placeholder">Content will appear here</div>;

    const renderLatex = (text) => {
        try {
            // Check if the text contains LaTeX delimiters
            const hasDisplayMath = text.includes('\\[') && text.includes('\\]');
            const hasInlineMath = text.includes('\\(') && text.includes('\\)');

            // If no delimiters found, assume it's a plain LaTeX expression
            if (!hasDisplayMath && !hasInlineMath) {
                return isInline ? <InlineMath math={text} /> : <BlockMath math={text} />;
            }

            // Process text with delimiters
            let result = [];
            let remainingText = text;

            while (remainingText.length > 0) {
                // Find the next math block
                const inlineStart = remainingText.indexOf('\\(');
                const displayStart = remainingText.indexOf('\\[');

                // Determine which comes first
                let nextMathStart = -1;
                let nextMathEnd = -1;
                let isDisplay = false;

                if (displayStart >= 0 && (inlineStart < 0 || displayStart < inlineStart)) {
                    nextMathStart = displayStart;
                    nextMathEnd = remainingText.indexOf('\\]', displayStart + 2);
                    isDisplay = true;
                } else if (inlineStart >= 0) {
                    nextMathStart = inlineStart;
                    nextMathEnd = remainingText.indexOf('\\)', inlineStart + 2);
                }

                // If no more math found, add remaining text
                if (nextMathStart < 0) {
                    result.push(<span key={remainingText}>{remainingText}</span>);
                    break;
                }

                // Add text before math
                if (nextMathStart > 0) {
                    result.push(<span key={remainingText.substring(0, nextMathStart)}>
                        {remainingText.substring(0, nextMathStart)}
                    </span>);
                }

                // Add math content
                if (nextMathEnd > nextMathStart) {
                    const mathContent = remainingText.substring(
                        nextMathStart + (isDisplay ? 2 : 2),
                        nextMathEnd
                    );

                    result.push(isDisplay ? (
                        <BlockMath key={mathContent} math={mathContent} />
                    ) : (
                        <InlineMath key={mathContent} math={mathContent} />
                    ));

                    remainingText = remainingText.substring(nextMathEnd + (isDisplay ? 2 : 2));
                } else {
                    // Unmatched delimiter, add as text
                    result.push(<span key={remainingText.substring(nextMathStart)}>
                        {remainingText.substring(nextMathStart)}
                    </span>);
                    remainingText = '';
                }
            }

            return <>{result}</>;
        } catch (e) {
            console.error("LaTeX rendering error:", e);
            return <div className="latex-error">LaTeX rendering error: {e.message}</div>;
        }
    };

    const renderMixedContent = () => {
        try {
            // Split content into segments of HTML and LaTeX
            const segments = [];
            let remaining = content;

            while (remaining.length > 0) {
                // Find the next LaTeX block
                const inlineStart = remaining.indexOf('\\(');
                const displayStart = remaining.indexOf('\\[');

                let nextLatexStart = -1;
                let nextLatexEnd = -1;
                let isDisplay = false;

                // Determine which LaTeX block comes first
                if (displayStart >= 0 && (inlineStart < 0 || displayStart < inlineStart)) {
                    nextLatexStart = displayStart;
                    nextLatexEnd = remaining.indexOf('\\]', displayStart + 2);
                    isDisplay = true;
                } else if (inlineStart >= 0) {
                    nextLatexStart = inlineStart;
                    nextLatexEnd = remaining.indexOf('\\)', inlineStart + 2);
                }

                // If no LaTeX found, add remaining as HTML
                if (nextLatexStart < 0) {
                    segments.push({
                        type: 'html',
                        content: DOMPurify.sanitize(remaining)
                    });
                    break;
                }

                // Add HTML before LaTeX
                if (nextLatexStart > 0) {
                    segments.push({
                        type: 'html',
                        content: DOMPurify.sanitize(remaining.substring(0, nextLatexStart))
                    });
                }

                // Add LaTeX content
                if (nextLatexEnd > nextLatexStart) {
                    const latexContent = remaining.substring(
                        nextLatexStart + (isDisplay ? 2 : 2),
                        nextLatexEnd
                    );

                    segments.push({
                        type: isDisplay ? 'display' : 'inline',
                        content: latexContent
                    });

                    remaining = remaining.substring(nextLatexEnd + (isDisplay ? 2 : 2));
                } else {
                    // Unmatched delimiter, add as HTML
                    segments.push({
                        type: 'html',
                        content: DOMPurify.sanitize(remaining.substring(nextLatexStart))
                    });
                    remaining = '';
                }
            }

            // Render all segments
            return (
                <div>
                    {segments.map((segment, index) => {
                        if (segment.type === 'html') {
                            return <span key={index} dangerouslySetInnerHTML={{ __html: segment.content }} />;
                        } else if (segment.type === 'display') {
                            return <BlockMath key={index} math={segment.content} />;
                        } else {
                            return <InlineMath key={index} math={segment.content} />;
                        }
                    })}
                </div>
            );
        } catch (e) {
            console.error("Rendering error:", e);
            return <div className="error">Error rendering content: {e.message}</div>;
        }
    };

    return isInline ? renderLatex(content) : renderMixedContent();
};

export const cleanLatex = (text) => {
    return text.replace(/\\[{}]/g, '');
};

export default LatexRenderer;