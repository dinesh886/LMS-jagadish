import React from 'react'

const TestDetail = () => {
  return (
    <div>TestDetail</div>
  )
}

export default TestDetail