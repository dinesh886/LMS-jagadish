"use client"

// CurrentRunningTestDetails.jsx
import { useState, useRef, useEffect } from "react"
import "./CurrentRunningTestDetails.css"
import {
  Clock,
  Users,
  Timer,
  FileText,
  User,
  HelpCircle,
  Target,
  BookOpen,
  Users2,
  ChevronDown,
  ChevronUp,
  MoreVertical,
  Send,
  Power,
  BarChart2,
  MonitorX,
  Forward
} from "lucide-react"
import DataTable from "../../../ReusableComponents/TableComponent/TableComponent"
import { toast } from "react-toastify"
import Header from "../../../header/header"
import { IoMdCheckmark, IoMdClose } from 'react-icons/io';

const CurrentRunningTestDetails = () => {
  const [expandedSection, setExpandedSection] = useState(null)
  const [openDropdown, setOpenDropdown] = useState(null)
  const [suspendedStates, setSuspendedStates] = useState({});
  const [hoveredScoreKey, setHoveredScoreKey] = useState(null);
  const [searchQuery, setSearchQuery] = useState("");

  // Hardcoded sample data for the table
  const sampleCandidates = [
    {
      id: 1,
      name: "student1",
      email: "student1@example.com",
      class: "Enrolled 10-A",
      rank: 1,
      a: 45,
      c: 40,
      w: 2,
      gs: 88,
      ns: 85,
      joinTime: "5",
      leaveTime: "3",
      status: "Running",
    },
    {
      id: 2,
      name: "student2",
      email: "student2@example.com",
      class: "Invited",
      rank: 2,
      a: 42,
      c: 38,
      w: 3,
      gs: 85,
      ns: 80,
      joinTime: "2",
      leaveTime: "3",
      status: "Submitted",
    },
    {
      id: 3,
      name: "student3",
      email: "student3@example.com",
      class: "Enrolled 10-B",
      rank: 3,
      a: 30,
      c: 25,
      w: 4,
      gs: 70,
      ns: 65,
      joinTime: "2",
      leaveTime: "2",
      status: "Absent",
    },
    {
      id: 4,
      name: "student4",
      email: "student4@example.com",
      class: "Guest",
      rank: 4,
      a: 48,
      c: 44,
      w: 1,
      gs: 90,
      ns: 88,
      joinTime: "3",
      leaveTime: "5",
      status: "Logout",
    },
  ];

  // Filter candidates based on search query
  const filteredCandidates = sampleCandidates.filter(candidate => {
    const searchLower = searchQuery.toLowerCase();
    return (
      candidate.name.toLowerCase().includes(searchLower) ||
      candidate.email.toLowerCase().includes(searchLower) ||
      candidate.class.toLowerCase().includes(searchLower) ||
      candidate.status.toLowerCase().includes(searchLower) ||
      candidate.rank.toString().includes(searchQuery)
    );
  });

  // Sample test data for top cards and test details
  const testData = {
    hoursConsumed: "24/100",
    candidatesAttended: 150,
    timerDuration: "01:30:00",
    name: "Advanced Mathematics",
    owner: "Dr. Jane Smith",
    questions: 50,
    marks: 100,
    sections: 7,
    classbatch:"Public",
    description: "This is a test for advanced mathematics topics.",
    instructions: "Follow the on-screen instructions during the test.",
  };

  const dropdownRef = useRef(null);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setOpenDropdown(null);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  const toggleSection = (section) => {
    setExpandedSection(expandedSection === section ? null : section)
  }

  const handleSuspendResume = (row) => {
    const action = row.status === "Running" ? "suspended" : "resumed"
    toast.success(`Candidate ${row.name} has been ${action} `)
    setOpenDropdown(null)
  }

  const handleSuspendToggle = (row) => {
    const updatedStates = {
      ...suspendedStates,
      [row.id]: !suspendedStates[row.id],
    };
    setSuspendedStates(updatedStates);

    if (updatedStates[row.id]) {
      toast.error(`${row.name} has been suspended`);
    } else {
      toast.success(`${row.name} has been resumed`);
    }

    setOpenDropdown(null);
  };

  const handleBulkSuspend = (selectedRows) => {
    const updatedStates = { ...suspendedStates };
    selectedRows.forEach(row => {
      updatedStates[row.id] = true;
    });
    setSuspendedStates(updatedStates);

    const names = selectedRows.map(row => row.name).join(', ');
    toast.error(`Suspended ${selectedRows.length} students: ${names}`);
  };

  const handleBulkTerminate = (selectedRows) => {
    const names = selectedRows.map(row => row.name).join(', ');
    toast.error(`Terminated ${selectedRows.length} students: ${names}`);
  };

  const handleBulkSendMessage = (selectedRows) => {
    const names = selectedRows.map(row => row.name).join(', ');
    toast.info(`Notification sent to ${selectedRows.length} students: ${names}`);
  };

  const handleTerminate = (row) => {
    toast.info(`${row.name} has been terminated`)
    setOpenDropdown(null)
  }

  const handleSendNotification = (row) => {
    toast.info(`Notification sent to ${row.name} `)
    setOpenDropdown(null)
  }

  const handleDropdownToggle = (rowId) => {
    setOpenDropdown(openDropdown === rowId ? null : rowId)
  }

  const handleSearchChange = (value) => {
    setSearchQuery(value);
  };

  const columns = [
    {
      name: "Name",
      selector: (row) => row.name || "N/A",
      sortable: true,
      cell: (row) => <span>{row.name || "N/A"}</span>,
    },
    {
      name: "Email",
      selector: (row) => row.email || "N/A",
      sortable: true,
      cell: (row) => <span>{row.email || "N/A"}</span>,
    },
    {
      name: "Class",
      selector: (row) => row.class || "N/A",
      sortable: true,
      cell: (row) => <span>{row.class || "N/A"}</span>,
    },
    {
      name: (
        <div className="grouped-header">
          <div className="main-header">A-C-W-GS-NS</div>
          <div className="sub-headers">
            {['a', 'c', 'w', 'gs', 'ns'].map((key, i) => (
              <span
                key={key}
                data-key={key}
                onMouseEnter={() => setHoveredScoreKey(key)}
                onMouseLeave={() => setHoveredScoreKey(null)}
                className={`sub-header-item ${hoveredScoreKey === key ? 'highlight' : ''}`}
              >
                {['A', 'C', 'W', 'GS', 'NS'][i]}
              </span>
            ))}
          </div>
        </div>
      ),
      cell: (row) => (
        <div className="score-grid">
          {['a', 'c', 'w', 'gs', 'ns'].map((key) => (
            <div
              key={key}
              className={`score-cell ${hoveredScoreKey === key ? 'highlight' : ''}`}
              onMouseEnter={() => setHoveredScoreKey(key)}
              onMouseLeave={() => setHoveredScoreKey(null)}
              title={
                {
                  a: 'Attempts',
                  c: 'Correct',
                  w: 'Wrong',
                  gs: 'Gross Score',
                  ns: 'Net Score'
                }[key]
              }
            >
              {row[key] || 0}
            </div>
          ))}
        </div>
      ),
      sortable: false,
    },
    {
      name: "Rank",
      selector: (row) => row.rank || "N/A",
      sortable: true,
      cell: (row) => <span className="status-rank">{row.rank || "N/A"}</span>,
    },
    {
      name: (
        <div className="grouped-header">
          <div className="main-header">Exam Status</div>
          <div className="sub-headers status-headers">
            <span>IN</span>
            <span>OUT</span>
          </div>
        </div>
      ),
      cell: (row) => (
        <div className="status-grid">
          <span className="status-time">{row.joinTime || "--"}</span>
          <span className="status-time">{row.leaveTime || "--"}</span>
        </div>
      ),
      sortable: false,
    },
    {
      name: "Status",
      selector: (row) => row.status || "N/A",
      cell: (row) => <span className={`status  ${row.status?.toLowerCase() || "na"} `}>{row.status || "N/A"}</span>,
      sortable: true,
    },
    {
      name: "Options",
      cell: (row) => (
        <div className="options-dropdown-container"
          ref={openDropdown === row.id ? dropdownRef : null}
        >
          <button
            className="options-dropdown-toggle"
            onClick={(e) => {
              e.stopPropagation();
              handleDropdownToggle(row.id);
            }}
          >
            <MoreVertical size={16} />
          </button>
          {openDropdown === row.id && (
            <div className="options-dropdown-menu">
              <div
                className={`options-status-toggle ${suspendedStates[row.id] ? "disabled" : "enabled"}`}
                onClick={(e) => {
                  e.stopPropagation();
                  handleSuspendToggle(row);
                }}
              >
                <button className="options-dropdown-item">
                  <MonitorX size={14} />
                  {suspendedStates[row.id] ? "Resume" : "Suspend"}
                  <div className="options-status-toggle-track">
                    <div
                      className={`options-status-toggle-thumb ${suspendedStates[row.id] ? "disabled" : "enabled"}`}
                    >
                      {!suspendedStates[row.id] ? (
                        <IoMdCheckmark className="status-icon" />
                      ) : (
                        <IoMdClose className="status-icon" />
                      )}
                    </div>
                  </div>
                </button>
              </div>
              <button
                className="options-dropdown-item"
                onClick={(e) => {
                  e.stopPropagation();
                  handleTerminate(row);
                }}
              >
                <Power size={14} /> Terminate
              </button>
              <button
                className="options-dropdown-item options-dropdown-item3"
                onClick={(e) => {
                  e.stopPropagation();
                  handleSendNotification(row);
                }}
              >
                <Forward size={14} />
                Send Notification
              </button>
            </div>
          )}
        </div>
      ),
      ignoreRowClick: true,
      allowOverflow: true,
      button: true,
    }
  ];

  return (
    <>
      <Header />
      <div className="test-details-container">
        <div className="top-cards-container">
          <div className="top-card">
            <div className="card-icon">
              <Clock size={24} />
            </div>
            <div className="card-content">
              <h3>Hours Consumed</h3>
              <p>{testData.hoursConsumed}</p>
            </div>
          </div>
          <div className="top-card">
            <div className="card-icon">
              <Users size={24} />
            </div>
            <div className="card-content">
              <h3>Candidates Attended</h3>
              <p>{testData.candidatesAttended}</p>
            </div>
          </div>
          <div className="top-card">
            <div className="card-icon">
              <Timer size={24} />
            </div>
            <div className="card-content">
              <h3>Timer </h3>
              <p className="time-remaining">{testData.timerDuration}</p>
            </div>
          </div>
        </div>

        <div className="main-card">
          <h2>Test Details</h2>
          <div className="test2-info">
            <div className="info-item">
              <div className="info-icon">
                <FileText size={20} />
              </div>
              <div className="info-content">
                <strong>Test Name:</strong>
                <span>{testData.name}</span>
              </div>
            </div>
            <div className="info-item">
              <div className="info-icon">
                <User size={20} />
              </div>
              <div className="info-content">
                <strong>Owner:</strong>
                <span>{testData.owner}</span>
              </div>
            </div>
            <div className="info-item">
              <div className="info-icon">
                <HelpCircle size={20} />
              </div>
              <div className="info-content">
                <strong>Questions:</strong>
                <span>{testData.questions}</span>
              </div>
            </div>
            <div className="info-item">
              <div className="info-icon">
                <Target size={20} />
              </div>
              <div className="info-content">
                <strong>Marks:</strong>
                <span>{testData.marks}</span>
              </div>
            </div>
            <div className="info-item">
              <div className="info-icon">
                <BookOpen size={20} />
              </div>
              <div className="info-content">
                <strong>Sections:</strong>
                <span>{testData.sections}</span>
              </div>
            </div>
            <div className="info-item">
              <div className="info-icon">
                <FileText size={20} />
              </div>
              <div className="info-content">
                <strong>View Question Paper:</strong>
                <span>{testData.owner}</span>
              </div>
            </div>
            <div className="info-item">
              <div className="info-icon">
                <Users2 size={20} />
              </div>
              <div className="info-content">
                <strong>Class/Batch:</strong>
                <span>{testData.classbatch}</span>
              </div>
            </div>
            <div className="info-item">
              <div className="info-icon">
                <Target size={20} />
              </div>
              <div className="info-content">
                <strong>Marks:</strong>
                <span>{testData.marks}</span>
              </div>
            </div>
          </div>

          <div className="accordion">
            <div className="accordion-item">
              <button
                className={`accordion-header ${expandedSection === "description" ? "active" : ""}`}
                onClick={() => toggleSection("description")}
              >
                Description
                <span className="accordion-icon">
                  {expandedSection === "description" ? <ChevronUp size={18} /> : <ChevronDown size={18} />}
                </span>
              </button>
              {expandedSection === "description" && (
                <div className="accordion-content">
                  <p>{testData.description}</p>
                </div>
              )}
            </div>
            <div className="accordion-item">
              <button
                className={`accordion-header ${expandedSection === "instructions" ? "active" : ""}`}
                onClick={() => toggleSection("instructions")}
              >
                Instructions
                <span className="accordion-icon">
                  {expandedSection === "instructions" ? <ChevronUp size={18} /> : <ChevronDown size={18} />}
                </span>
              </button>
              {expandedSection === "instructions" && (
                <div className="accordion-content">
                  <p>{testData.instructions}</p>
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="candidate-details-card">
          <div className="status-header">
            <div className="status-title status-title2">
              <BarChart2 size={20} className="status-title-icon" />
              <h3>Student Performance</h3>
            </div>
            <div className="status-subtitle status-subtitle2">
              Student Table ({filteredCandidates.length})
            </div>
          </div>
          <DataTable
            columns={columns}
            data={filteredCandidates}
            pagination
            highlightOnHover
            studentActions={["suspend", "terminate", "sendMessage"]}
            onBulkSuspend={handleBulkSuspend}
            onBulkTerminate={handleBulkTerminate}
            onBulkSendMessage={handleBulkSendMessage}
            searchoption={true}
            searchQuery={searchQuery}
            onSearchChange={handleSearchChange}
          />
          <div className="score-legend">
            <p>Score Legend:</p>
            <ul>
              {[
                { key: 'a', label: 'Attempts' },
                { key: 'c', label: 'Correct' },
                { key: 'w', label: 'Wrong' },
                { key: 'gs', label: 'Gross Score' },
                { key: 'ns', label: 'Net Score' }
              ].map(({ key, label }) => (
                <li key={key} className={hoveredScoreKey === key ? 'highlight' : ''}>
                  <strong>{key.toUpperCase()}:</strong> {label}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </>
  )
}

export default CurrentRunningTestDetails