import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import './UpcomingTestDetails.css';
import {
  Clock,
  Users,
  Timer,
  FileText,
  User,
  HelpCircle,
  Target,
  BookOpen,
  Users2,
  ChevronDown,
  ChevronUp,
  BarChart2
} from 'lucide-react';
import DataTable from '../../../ReusableComponents/TableComponent/TableComponent';
import Header from '../../../header/header';
import clock from '../../../../images/clock.png';

const UpcomingTestDetails = () => {
  const { id } = useParams();
  const [expandedSection, setExpandedSection] = useState(null);

  const testData = {
    hoursConsumed: 0,
    candidatesAttended: 0,
    timerDuration: '01:20:00',
    name: 'Advanced JavaScript Assessment',
    owner: 'John Doe',
    questions: 50,
    marks: 100,
    sections: 3,
    description: 'This test evaluates advanced JavaScript concepts including closures, prototypes, and async programming.',
    instructions: 'Please read each question carefully. You have 2.5 hours to complete the test. Good luck!',
    candidates: [
      {
        id: 1,
        name: 'Alice Johnson',
        email: 'alice@example.com',
        class: 'JavaScript 101',
        status: 'Enrolled'
      },
      {
        id: 2,
        name: 'Bob Smith',
        email: 'bob@example.com',
        class: 'Guest',
        status: 'Invited'
      },
      {
        id: 3,
        name: 'Charlie Brown',
        email: 'charlie@example.com',
        class: 'Public',
        status: 'Pending'
      }
    ]
  };

  const toggleSection = (section) => {
    setExpandedSection(expandedSection === section ? null : section);
  };

  const columns = [
    {
      name: "Name",
      selector: "Name",
      sortable: true,
      cell: (row) => <span>{row.name || "N/A"}</span>,
    },
    {
      name: "Email",
      selector: "Email",
      sortable: true,
      cell: (row) => <span>{row.email || "N/A"}</span>,
    },
    {
      name: "Class",
      selector: "Class",
      sortable: true,
      cell: (row) => <span>{row.class || "N/A"}</span>,
    },
    {
      name: "Status",
      selector: "Status",
      cell: (row) => <span className={`status ${row.status?.toLowerCase() || "na"}`}>{row.status || "N/A"}</span>,
      sortable: true,
    }
  ];

  return (
    <>
      <Header />
      <div className="test-details-container">
       

        <div className="top-cards-container">
          <div className="top-card">
            <div className="card-icon">
              <Clock size={24} />
            </div>
            <div className="card-content">
              <h3>Hours Consumed</h3>
              <p>{testData.hoursConsumed}/100</p>
            </div>
          </div>
          <div className="top-card">
            <div className="card-icon">
              <Users size={24} />
            </div>
            <div className="card-content">
              <h3>Candidates Attended</h3>
              <p>{testData.candidatesAttended}</p>
            </div>
          </div>
          <div className="top-card">
            <div className="card-icon">
              <Timer size={24} />
            </div>
            <div className="card-content">
              <h3>Timer</h3>
              <p>{testData.timerDuration}</p>
            </div>
          </div>
        </div>

        <div className="main-card">
          <h2>Test Details</h2>
          <div className="test2-info">
            <div className="info-item">
              <div className="info-icon">
                <FileText size={20} />
              </div>
              <div className="info-content">
                <strong>Name:</strong>
                <span>{testData.name}</span>
              </div>
            </div>
            <div className="info-item">
              <div className="info-icon">
                <User size={20} />
              </div>
              <div className="info-content">
                <strong>Owner:</strong>
                <span>{testData.owner}</span>
              </div>
            </div>
            <div className="info-item">
              <div className="info-icon">
                <HelpCircle size={20} />
              </div>
              <div className="info-content">
                <strong>Questions:</strong>
                <span>{testData.questions}</span>
              </div>
            </div>
            <div className="info-item">
              <div className="info-icon">
                <Target size={20} />
              </div>
              <div className="info-content">
                <strong>Marks:</strong>
                <span>{testData.marks}</span>
              </div>
            </div>
            <div className="info-item">
              <div className="info-icon">
                <BookOpen size={20} />
              </div>
              <div className="info-content">
                <strong>Sections:</strong>
                <span>{testData.sections}</span>
              </div>
            </div>
            <div className="info-item">
              <div className="info-icon">
                <Users2 size={20} />
              </div>
              <div className="info-content">
                <strong>Class/Batch:</strong>
                <span>JavaScript Advanced</span>
              </div>
            </div>
          </div>

          <div className="accordion">
            <div className="accordion-item">
              <button
                className={`accordion-header ${expandedSection === 'description' ? 'active' : ''}`}
                onClick={() => toggleSection('description')}
              >
                Description
                <span className="accordion-icon">
                  {expandedSection === 'description' ? <ChevronUp size={18} /> : <ChevronDown size={18} />}
                </span>
              </button>
              {expandedSection === 'description' && (
                <div className="accordion-content">
                  <p>{testData.description}</p>
                </div>
              )}
            </div>
            <div className="accordion-item">
              <button
                className={`accordion-header ${expandedSection === 'instructions' ? 'active' : ''}`}
                onClick={() => toggleSection('instructions')}
              >
                Instructions
                <span className="accordion-icon">
                  {expandedSection === 'instructions' ? <ChevronUp size={18} /> : <ChevronDown size={18} />}
                </span>
              </button>
              {expandedSection === 'instructions' && (
                <div className="accordion-content">
                  <p>{testData.instructions}</p>
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="candidate-details-card">
          <div className="status-header">
            <div className="status-title status-title2">
              <BarChart2 size={20} className="status-title-icon" />
              <h3>Enrolled Candidates</h3>
            </div>
            <div className="status-subtitle status-subtitle2">
              Student Table ({testData.candidates.length})
            </div>
          </div>

          <DataTable
            columns={columns}
            data={testData.candidates}
            pagination
            highlightOnHover
          />
        </div>
      </div>
    </>
  );
}

export default UpcomingTestDetails;